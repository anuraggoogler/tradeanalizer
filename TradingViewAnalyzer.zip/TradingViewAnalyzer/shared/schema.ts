import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb, varchar, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Enhanced user table with trading profile
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  username: varchar("username", { length: 255 }).unique(),
  tradingExperience: varchar("trading_experience", { length: 50 }).default("beginner"),
  riskTolerance: varchar("risk_tolerance", { length: 50 }).default("low"),
  accountBalance: decimal("account_balance", { precision: 15, scale: 2 }).default("100000.00"),
  marginUsed: decimal("margin_used", { precision: 15, scale: 2 }).default("0.00"),
  totalPnL: decimal("total_pnl", { precision: 15, scale: 2 }).default("0.00"),
  dayPnL: decimal("day_pnl", { precision: 15, scale: 2 }).default("0.00"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const symbols = pgTable("symbols", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull().unique(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'CALL', 'PUT', 'FUTURE'
  underlyingAsset: text("underlying_asset").notNull(),
  strikePrice: decimal("strike_price", { precision: 10, scale: 2 }),
  expiryDate: timestamp("expiry_date"),
  lotSize: integer("lot_size").notNull().default(1),
  isActive: boolean("is_active").notNull().default(true),
});

export const marketData = pgTable("market_data", {
  id: serial("id").primaryKey(),
  symbolId: integer("symbol_id").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  open: decimal("open", { precision: 10, scale: 2 }).notNull(),
  high: decimal("high", { precision: 10, scale: 2 }).notNull(),
  low: decimal("low", { precision: 10, scale: 2 }).notNull(),
  close: decimal("close", { precision: 10, scale: 2 }).notNull(),
  volume: integer("volume").notNull().default(0),
  openInterest: integer("open_interest").default(0),
});

export const watchlists = pgTable("watchlists", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  symbolId: integer("symbol_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Enhanced Pine Script strategies table
export const pineScripts = pgTable("pine_scripts", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  code: text("code").notNull(),
  category: varchar("category", { length: 100 }).default("custom"),
  tags: text("tags").array(),
  isActive: boolean("is_active").notNull().default(false),
  isPublic: boolean("is_public").notNull().default(false),
  performance: jsonb("performance"),
  metadata: jsonb("metadata"),
  backtestResults: jsonb("backtest_results"),
  executionCount: integer("execution_count").default(0),
  lastExecuted: timestamp("last_executed"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Strategy executions log
export const strategyExecutions = pgTable("strategy_executions", {
  id: serial("id").primaryKey(),
  strategyId: integer("strategy_id").notNull(),
  symbolId: integer("symbol_id").notNull(),
  executedAt: timestamp("executed_at").defaultNow().notNull(),
  signals: jsonb("signals").notNull(),
  marketData: jsonb("market_data"),
  performance: jsonb("performance"),
  status: varchar("status", { length: 50 }).default("completed"),
});

// Trading positions
export const positions = pgTable("positions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  symbolId: integer("symbol_id").notNull(),
  strategyId: integer("strategy_id"),
  type: varchar("type", { length: 10 }).notNull(), // 'LONG', 'SHORT'
  quantity: integer("quantity").notNull(),
  entryPrice: decimal("entry_price", { precision: 10, scale: 2 }).notNull(),
  exitPrice: decimal("exit_price", { precision: 10, scale: 2 }),
  currentPrice: decimal("current_price", { precision: 10, scale: 2 }),
  pnl: decimal("pnl", { precision: 10, scale: 2 }).default("0.00"),
  margin: decimal("margin", { precision: 10, scale: 2 }).notNull(),
  status: varchar("status", { length: 20 }).default("open"), // 'open', 'closed', 'partial'
  entryTime: timestamp("entry_time").defaultNow().notNull(),
  exitTime: timestamp("exit_time"),
});

// Enhanced alerts system
export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  symbolId: integer("symbol_id").notNull(),
  alertType: varchar("alert_type", { length: 50 }).notNull(), // 'price', 'volume', 'indicator'
  condition: text("condition").notNull(),
  targetPrice: decimal("target_price", { precision: 10, scale: 2 }),
  currentValue: decimal("current_value", { precision: 10, scale: 2 }),
  message: text("message"),
  isTriggered: boolean("is_triggered").notNull().default(false),
  triggerTime: timestamp("trigger_time"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Trading orders
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  symbolId: integer("symbol_id").notNull(),
  strategyId: integer("strategy_id"),
  type: varchar("type", { length: 20 }).notNull(), // 'BUY', 'SELL', 'STOP_LOSS', 'TAKE_PROFIT'
  orderType: varchar("order_type", { length: 20 }).notNull(), // 'MARKET', 'LIMIT', 'STOP'
  quantity: integer("quantity").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }),
  triggerPrice: decimal("trigger_price", { precision: 10, scale: 2 }),
  executedPrice: decimal("executed_price", { precision: 10, scale: 2 }),
  executedQuantity: integer("executed_quantity").default(0),
  status: varchar("status", { length: 20 }).default("pending"), // 'pending', 'executed', 'cancelled', 'partial'
  timeInForce: varchar("time_in_force", { length: 10 }).default("DAY"), // 'DAY', 'GTC', 'IOC'
  placedAt: timestamp("placed_at").defaultNow().notNull(),
  executedAt: timestamp("executed_at"),
});

// Insert schemas for authentication
export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const upsertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertSymbolSchema = createInsertSchema(symbols).omit({
  id: true,
});

export const insertMarketDataSchema = createInsertSchema(marketData).omit({
  id: true,
  timestamp: true,
});

export const insertWatchlistSchema = createInsertSchema(watchlists).omit({
  id: true,
  createdAt: true,
});

export const insertPineScriptSchema = createInsertSchema(pineScripts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpsertUser = z.infer<typeof upsertUserSchema>;

export type Symbol = typeof symbols.$inferSelect;
export type InsertSymbol = z.infer<typeof insertSymbolSchema>;

export type MarketData = typeof marketData.$inferSelect;
export type InsertMarketData = z.infer<typeof insertMarketDataSchema>;

export type Watchlist = typeof watchlists.$inferSelect;
export type InsertWatchlist = z.infer<typeof insertWatchlistSchema>;

export type PineScript = typeof pineScripts.$inferSelect;
export type InsertPineScript = z.infer<typeof insertPineScriptSchema>;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

// Market data types for real-time updates
export interface LiveMarketData {
  symbol: string;
  ltp: number;
  change: number;
  changePercent: number;
  volume: number;
  openInterest?: number;
  bid: number;
  ask: number;
  timestamp: number;
}

export interface OrderBookEntry {
  price: number;
  quantity: number;
  orders: number;
}

export interface OrderBook {
  symbol: string;
  bids: OrderBookEntry[];
  asks: OrderBookEntry[];
  timestamp: number;
}

export interface PineScriptSignal {
  symbol: string;
  action: 'BUY' | 'SELL' | 'HOLD';
  price: number;
  quantity: number;
  timestamp: number;
  strategy: string;
  confidence: number;
}
