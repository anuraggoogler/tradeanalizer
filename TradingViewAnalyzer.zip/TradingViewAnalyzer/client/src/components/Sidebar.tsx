import { Link, useLocation } from "wouter";

export default function Sidebar() {
  const [location] = useLocation();

  const navItems = [
    { path: "/", icon: "fas fa-home", label: "Dashboard", active: true },
    { path: "/trading", icon: "fas fa-chart-area", label: "Trading Charts" },
    { path: "/pinescript", icon: "fas fa-code", label: "Pine Script" },
    { path: "/watchlist", icon: "fas fa-list", label: "Watchlist" },
    { path: "/risk", icon: "fas fa-calculator", label: "Risk Tools" },
  ];

  const quickAccessItems = [
    { path: "/alerts", icon: "fas fa-bell", label: "Alerts", badge: "3" },
    { path: "/history", icon: "fas fa-history", label: "History" },
    { path: "/settings", icon: "fas fa-cog", label: "Settings" },
  ];

  return (
    <aside className="w-64 bg-slate-800 border-r border-slate-700 flex flex-col">
      {/* Logo */}
      <div className="p-4 border-b border-slate-700">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gradient-to-br from-primary-500 to-primary-700 rounded-lg flex items-center justify-center">
            <i className="fas fa-chart-line text-white text-sm"></i>
          </div>
          <div>
            <h1 className="font-bold text-lg text-white">TradeMaster Pro</h1>
            <p className="text-xs text-slate-400">Professional F&O Trading</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        <div className="space-y-1">
          {navItems.map((item) => (
            <Link 
              key={item.path}
              href={item.path}
              className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                location === item.path
                  ? 'bg-primary-600 text-white'
                  : 'text-slate-300 hover:bg-slate-700'
              }`}
            >
              <i className={`${item.icon} text-sm`}></i>
              <span className="text-sm font-medium">{item.label}</span>
            </Link>
          ))}
        </div>

        <div className="pt-4">
          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
            Quick Access
          </h3>
          <div className="space-y-1">
            {quickAccessItems.map((item) => (
              <Link
                key={item.path}
                href={item.path}
                className="flex items-center space-x-3 px-3 py-2 rounded-lg text-slate-300 hover:bg-slate-700 transition-colors"
              >
                <i className={`${item.icon} text-sm`}></i>
                <span className="text-sm">{item.label}</span>
                {item.badge && (
                  <span className="ml-auto bg-red-500 text-white text-xs rounded-full px-2 py-0.5">
                    {item.badge}
                  </span>
                )}
              </Link>
            ))}
          </div>
        </div>
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t border-slate-700">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center">
            <span className="text-white text-sm font-medium">JD</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">John Doe</p>
            <p className="text-xs text-slate-400">Online</p>
          </div>
          <button className="text-slate-400 hover:text-white transition-colors">
            <i className="fas fa-ellipsis-h text-sm"></i>
          </button>
        </div>
      </div>
    </aside>
  );
}
