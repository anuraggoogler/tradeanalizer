import { useEffect, useRef } from "react";
import { type LiveMarketData } from "@shared/schema";

interface TradingChartProps {
  symbol: string;
  timeframe: string;
  marketData?: LiveMarketData;
}

declare global {
  interface Window {
    TradingView: any;
  }
}

export default function TradingChart({ symbol, timeframe, marketData }: TradingChartProps) {
  const chartContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    console.log(`TradingChart useEffect triggered with symbol: ${symbol}, timeframe: ${timeframe}`);
    
    if (!chartContainerRef.current) {
      console.log('Chart container ref not available');
      return;
    }

    // Clear container
    chartContainerRef.current.innerHTML = '';

    // Map F&O symbols to valid TradingView symbols
    let tvSymbol = "AAPL"; // Default fallback that definitely works
    if (symbol.includes("BANKNIFTY")) {
      tvSymbol = "AAPL"; // Use Apple for BANKNIFTY F&O
    } else if (symbol.includes("RELIANCE")) {
      tvSymbol = "AAPL"; // Use Apple for RELIANCE F&O
    } else if (symbol.includes("NIFTY")) {
      tvSymbol = "AAPL"; // Use Apple for NIFTY F&O
    }
    
    console.log(`Updated symbol mapping: ${symbol} -> ${tvSymbol}`);
    
    console.log(`Chart switching: ${symbol} -> ${tvSymbol}`);

    // Create widget container
    const widgetContainer = document.createElement('div');
    widgetContainer.className = 'tradingview-widget-container';
    widgetContainer.style.height = '100%';
    widgetContainer.style.width = '100%';

    const widgetDiv = document.createElement('div');
    widgetDiv.className = 'tradingview-widget-container__widget';
    widgetDiv.style.height = 'calc(100% - 32px)';
    widgetDiv.style.width = '100%';

    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js';
    script.async = true;

    const chartConfig = {
      autosize: true,
      symbol: tvSymbol,
      interval: timeframe === "1m" ? "1" : timeframe === "5m" ? "5" : "15",
      timezone: "Asia/Kolkata",
      theme: "dark",
      style: "1",
      locale: "en",
      toolbar_bg: "#1e293b",
      enable_publishing: false,
      allow_symbol_change: true, // Allow symbol change to test availability
      calendar: false,
      hide_top_toolbar: false,
      hide_legend: false,
      hide_side_toolbar: false,
      details: false,
      hotlist: false,
      withdateranges: false,
      hide_volume: false,
      support_host: "https://www.tradingview.com"
    };

    script.innerHTML = JSON.stringify(chartConfig);

    widgetContainer.appendChild(widgetDiv);
    widgetContainer.appendChild(script);
    chartContainerRef.current.appendChild(widgetContainer);

    return () => {
      if (chartContainerRef.current) {
        chartContainerRef.current.innerHTML = '';
      }
    };
  }, [symbol, timeframe]);

  return (
    <div className="w-full h-full bg-slate-900">
      <div ref={chartContainerRef} className="w-full h-full relative">
        {/* Loading indicator */}
        <div className="absolute inset-0 flex items-center justify-center text-slate-400 pointer-events-none z-10">
          <div className="text-center">
            <div className="text-lg mb-2">📈 Loading Chart...</div>
            <div className="text-sm font-mono">
              {symbol.replace(/_/g, ' ')}
            </div>
            <div className="text-xs mt-2 text-slate-500">
              Testing with: AAPL (all F&O symbols)
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Extend Window interface for TradingView
declare global {
  interface Window {
    TradingView: any;
  }
}
