import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";

interface PineScriptEditorProps {
  onClose: () => void;
  selectedSymbol: string;
}

export default function PineScriptEditor({ onClose, selectedSymbol }: PineScriptEditorProps) {
  const [code, setCode] = useState(defaultPineScript);
  const [isRunning, setIsRunning] = useState(false);
  const { toast } = useToast();

  const { data: scripts } = useQuery({
    queryKey: ['/api/pinescripts'],
  });

  const { data: symbols } = useQuery({
    queryKey: ['/api/symbols'],
  });

  const saveMutation = useMutation({
    mutationFn: async (scriptData: { name: string; code: string }) => {
      const response = await fetch('/api/pinescripts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(scriptData),
      });

      if (!response.ok) {
        throw new Error('Failed to save Pine Script');
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/pinescripts'] });
      toast({
        title: "Script Saved",
        description: "Your Pine Script has been saved successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save Pine Script",
        variant: "destructive",
      });
    },
  });

  const executeMutation = useMutation({
    mutationFn: async () => {
      // Find the symbol ID for the selected symbol
      const symbol = symbols?.find((s: any) => s.symbol === selectedSymbol);
      if (!symbol) {
        throw new Error('Symbol not found');
      }

      // First save the script
      const saveResponse = await fetch('/api/pinescripts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: 'Temp Execution Script',
          code: code,
        }),
      });

      if (!saveResponse.ok) {
        throw new Error('Failed to save script for execution');
      }

      const savedScript = await saveResponse.json();

      // Then execute it
      const executeResponse = await fetch(`/api/pinescripts/${savedScript.id}/execute`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          symbolId: symbol.id,
        }),
      });

      if (!executeResponse.ok) {
        throw new Error('Failed to execute Pine Script');
      }

      return executeResponse.json();
    },
    onSuccess: (result) => {
      setIsRunning(true);
      toast({
        title: "Script Executed",
        description: `Script running successfully. Generated ${result.signals?.length || 0} signals.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Execution Error",
        description: error instanceof Error ? error.message : "Failed to execute Pine Script",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    saveMutation.mutate({
      name: `Custom Strategy ${new Date().toLocaleDateString()}`,
      code: code,
    });
  };

  const handleRun = () => {
    executeMutation.mutate();
  };

  const handleStop = () => {
    setIsRunning(false);
    toast({
      title: "Script Stopped",
      description: "Pine Script execution has been stopped",
    });
  };

  // Mock execution results for demo
  const mockResults = {
    totalTrades: 24,
    winRate: 75.0,
    netPnL: 8450.25,
    maxDrawdown: 1250.00,
    signals: [
      { action: 'BUY', time: '15:18:45', reason: 'RSI: 28.5 (Oversold)' },
      { action: 'SELL', time: '15:02:12', reason: 'RSI: 72.1 (Overbought)' },
    ]
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-slate-800 rounded-xl shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-purple-700 rounded-lg flex items-center justify-center">
              <i className="fas fa-code text-white text-sm"></i>
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Pine Script Editor</h2>
              <p className="text-sm text-slate-400">Create and execute custom trading strategies</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            onClick={onClose}
            className="text-slate-400 hover:text-white"
          >
            <i className="fas fa-times text-xl"></i>
          </Button>
        </div>

        <div className="flex h-96">
          {/* Pine Script Editor */}
          <div className="flex-1 flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-slate-700">
              <div className="flex items-center space-x-3">
                <select className="bg-slate-700 border border-slate-600 rounded px-3 py-1 text-sm text-white">
                  <option>Custom Strategy</option>
                  <option>RSI Divergence</option>
                  <option>Moving Average Cross</option>
                  <option>Bollinger Bands</option>
                </select>
                
                <Button 
                  onClick={isRunning ? handleStop : handleRun}
                  disabled={executeMutation.isPending}
                  className={`${
                    isRunning 
                      ? 'bg-red-600 hover:bg-red-700' 
                      : 'bg-primary-600 hover:bg-primary-700'
                  } text-white`}
                >
                  <i className={`fas ${isRunning ? 'fa-stop' : 'fa-play'} mr-1`}></i>
                  {isRunning ? 'Stop' : 'Run'}
                </Button>
                
                <Button 
                  onClick={handleSave}
                  disabled={saveMutation.isPending}
                  variant="outline"
                  className="bg-slate-600 border-slate-500 hover:bg-slate-500 text-white"
                >
                  <i className="fas fa-save mr-1"></i>
                  Save
                </Button>
              </div>
              <div className="text-sm text-slate-400">v6 | {isRunning ? 'Live Execution' : 'Ready'}</div>
            </div>
            
            {/* Code Editor */}
            <div className="flex-1 p-4">
              <Textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full h-full font-mono text-sm bg-slate-900 border-slate-600 text-white resize-none"
                placeholder="Enter your Pine Script code here..."
              />
            </div>
          </div>

          {/* Strategy Results */}
          <div className="w-80 border-l border-slate-700 bg-slate-850">
            <div className="p-4 border-b border-slate-700">
              <h3 className="font-semibold text-white mb-3">Execution Results</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-400">Status:</span>
                  <span className={`flex items-center ${isRunning ? 'text-green-400' : 'text-slate-400'}`}>
                    <i className={`fas ${isRunning ? 'fa-check-circle' : 'fa-circle'} mr-1`}></i>
                    {isRunning ? 'Running' : 'Stopped'}
                  </span>
                </div>
                {isRunning && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Total Trades:</span>
                      <span className="text-white font-mono">{mockResults.totalTrades}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Win Rate:</span>
                      <span className="text-green-400 font-mono">{mockResults.winRate}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Net P&L:</span>
                      <span className="text-green-400 font-mono">+₹{mockResults.netPnL.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Max Drawdown:</span>
                      <span className="text-red-400 font-mono">-₹{mockResults.maxDrawdown.toLocaleString()}</span>
                    </div>
                  </>
                )}
              </div>
            </div>

            {isRunning && (
              <div className="p-4">
                <h4 className="font-medium text-white mb-2">Recent Signals</h4>
                <div className="space-y-2 text-xs">
                  {mockResults.signals.map((signal, index) => (
                    <div key={index} className="bg-slate-700 rounded p-2">
                      <div className="flex justify-between items-center">
                        <span className={signal.action === 'BUY' ? 'text-green-400' : 'text-red-400'}>
                          {signal.action} Signal
                        </span>
                        <span className="text-slate-400">{signal.time}</span>
                      </div>
                      <div className="text-slate-300 mt-1">{signal.reason}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

const defaultPineScript = `// @version=6
strategy("F&O Trading Strategy", overlay=true, default_qty_type=strategy.percent_of_equity, default_qty_value=10)

// Input parameters
length = input.int(14, "RSI Length", minval=1)
rsi_overbought = input.int(70, "RSI Overbought")
rsi_oversold = input.int(30, "RSI Oversold")

// Calculate RSI
rsi_value = ta.rsi(close, length)

// Strategy conditions
long_condition = rsi_value < rsi_oversold
short_condition = rsi_value > rsi_overbought

// Execute trades
if (long_condition)
    strategy.entry("Long", strategy.long)

if (short_condition)
    strategy.entry("Short", strategy.short)

// Plot RSI
plot(rsi_value, "RSI", color=color.purple)
hline(70, "Overbought", color=color.red)
hline(30, "Oversold", color=color.green)
hline(50, "Midline", color=color.gray)`;
