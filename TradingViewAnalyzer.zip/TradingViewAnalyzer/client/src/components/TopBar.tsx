import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

interface TopBarProps {
  onSymbolSelect: (symbol: string) => void;
  selectedSymbol: string;
  isConnected: boolean;
}

export default function TopBar({ onSymbolSelect, selectedSymbol, isConnected }: TopBarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  
  // Mock market indices data
  const marketIndices = {
    NIFTY: { value: 18450.25, change: 125.30, changePercent: 0.68 },
    BANKNIFTY: { value: 42150.80, change: -89.45, changePercent: -0.21 },
  };

  const { data: searchResults } = useQuery({
    queryKey: ['/api/symbols/search', searchQuery],
    queryFn: async () => {
      if (searchQuery.length < 2) return [];
      const response = await fetch(`/api/symbols/search?q=${encodeURIComponent(searchQuery)}`);
      if (!response.ok) throw new Error('Search failed');
      return response.json();
    },
    enabled: searchQuery.length > 2,
  });

  const getCurrentTime = () => {
    return new Date().toLocaleTimeString('en-IN', {
      timeZone: 'Asia/Kolkata',
      hour12: false
    }) + ' IST';
  };

  return (
    <header className="bg-slate-800 border-b border-slate-700 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-6">
          {/* Market Status */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`}></div>
              <span className={`text-sm font-medium ${isConnected ? 'text-emerald-400' : 'text-red-400'}`}>
                {isConnected ? 'Market Open' : 'Disconnected'}
              </span>
            </div>
            
            {/* Market Indices */}
            <div className="text-sm text-slate-300">
              NIFTY: 
              <span className="text-emerald-400 font-mono ml-1">
                {marketIndices.NIFTY.value.toLocaleString()}
              </span>
              <span className="text-emerald-400 text-xs ml-1">
                +{marketIndices.NIFTY.change}
              </span>
            </div>
            
            <div className="text-sm text-slate-300">
              BANKNIFTY: 
              <span className="text-red-400 font-mono ml-1">
                {marketIndices.BANKNIFTY.value.toLocaleString()}
              </span>
              <span className="text-red-400 text-xs ml-1">
                {marketIndices.BANKNIFTY.change}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {/* Search Bar */}
          <div className="relative">
            <Input
              type="text"
              placeholder="Search symbols..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 w-64 pl-9"
            />
            <i className="fas fa-search absolute left-3 top-2.5 text-slate-400 text-sm"></i>
            
            {/* Search Results Dropdown */}
            {searchResults && searchResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-slate-800 border border-slate-600 rounded-lg shadow-lg z-50 max-h-60 overflow-y-auto">
                {searchResults.map((symbol: any) => (
                  <button
                    key={symbol.id}
                    onClick={() => {
                      onSymbolSelect(symbol.symbol);
                      setSearchQuery("");
                    }}
                    className="w-full text-left px-3 py-2 hover:bg-slate-700 text-sm text-white border-b border-slate-700 last:border-b-0"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">{symbol.name}</div>
                        <div className="text-xs text-slate-400">
                          Strike: ₹{symbol.strikePrice} | Lot: {symbol.lotSize}
                        </div>
                      </div>
                      <span className={`inline-block px-2 py-0.5 rounded text-xs ${
                        symbol.type === 'CALL' 
                          ? 'bg-blue-500 text-white' 
                          : 'bg-red-500 text-white'
                      }`}>
                        {symbol.type}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Current Time */}
          <div className="flex items-center space-x-2 text-sm text-slate-300">
            <i className="fas fa-clock text-slate-400"></i>
            <span>{getCurrentTime()}</span>
          </div>

          <Button className="bg-primary-600 hover:bg-primary-700 text-white">
            <i className="fas fa-plus mr-2"></i>
            New Chart
          </Button>
        </div>
      </div>
    </header>
  );
}
