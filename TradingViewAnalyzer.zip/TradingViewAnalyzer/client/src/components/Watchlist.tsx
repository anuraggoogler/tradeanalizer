import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface WatchlistProps {
  onSymbolSelect: (symbol: string) => void;
  selectedSymbol: string;
}

export default function Watchlist({ onSymbolSelect, selectedSymbol }: WatchlistProps) {
  const { toast } = useToast();

  const { data: watchlist, isLoading } = useQuery({
    queryKey: ['/api/watchlist'],
    refetchInterval: 5000, // Refetch every 5 seconds for live updates
  });

  const { data: allSymbols } = useQuery({
    queryKey: ['/api/symbols'],
  });

  const addToWatchlist = async (symbolId: number) => {
    try {
      const response = await fetch('/api/watchlist', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ symbolId }),
      });

      if (!response.ok) {
        throw new Error('Failed to add to watchlist');
      }

      toast({
        title: "Added to Watchlist",
        description: "Symbol has been added to your watchlist",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add symbol to watchlist",
        variant: "destructive",
      });
    }
  };

  const removeFromWatchlist = async (symbolId: number) => {
    try {
      const response = await fetch(`/api/watchlist/${symbolId}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error('Failed to remove from watchlist');
      }

      toast({
        title: "Removed from Watchlist",
        description: "Symbol has been removed from your watchlist",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to remove symbol from watchlist",
        variant: "destructive",
      });
    }
  };

  // All data comes from authenticated API endpoints only

  // Display real watchlist data only
  const displayWatchlist = watchlist || [];

  if (isLoading) {
    return (
      <div className="border-b border-slate-700 p-4 flex-1 min-h-0">
        <div className="flex items-center justify-center h-32">
          <div className="text-slate-400">Loading watchlist...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="border-b border-slate-700 p-4 flex-1 min-h-0">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-white flex items-center">
          <i className="fas fa-star mr-2 text-yellow-500"></i>
          Watchlist
        </h3>
        <Button 
          variant="ghost" 
          size="sm"
          onClick={() => {
            // Show available symbols for adding
            const availableSymbols = allSymbols?.filter(symbol => 
              !watchlist?.some((w: any) => w.symbolId === symbol.id)
            ) || [];
            if (availableSymbols.length > 0) {
              addToWatchlist(availableSymbols[0].id);
            }
          }}
          className="text-slate-400 hover:text-white p-1"
          title="Add symbol to watchlist"
        >
          <i className="fas fa-plus text-sm"></i>
        </Button>
      </div>
      
      <div className="space-y-2 overflow-y-auto max-h-64">
        {displayWatchlist.map((item: any) => (
          <div 
            key={item.id}
            onClick={() => {
              console.log(`Watchlist item clicked: ${item.symbol.symbol}`);
              onSymbolSelect(item.symbol.symbol);
            }}
            className={`bg-slate-700 rounded-lg p-3 hover:bg-slate-600 transition-colors cursor-pointer ${
              selectedSymbol === item.symbol.symbol ? 'ring-2 ring-emerald-500 bg-slate-600' : ''
            }`}
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium text-white text-sm">{item.symbol.name}</div>
                <div className="text-xs text-slate-400">
                  <span className={`inline-block px-2 py-0.5 rounded text-xs ${
                    item.symbol.type === 'CALL' 
                      ? 'bg-blue-500 text-white' 
                      : 'bg-red-500 text-white'
                  }`}>
                    {item.symbol.type}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <div className="font-mono text-sm text-slate-400">
                  Strike: ₹{item.symbol.strikePrice}
                </div>
                <div className="text-xs text-slate-500">
                  Lot: {item.symbol.lotSize}
                </div>
              </div>
            </div>
          </div>
        ))}

        {displayWatchlist.length === 0 && (
          <div className="text-center text-slate-400 py-8">
            <i className="fas fa-star text-2xl mb-2"></i>
            <p className="text-sm">No symbols in watchlist</p>
            <p className="text-xs">Add symbols to track their prices</p>
          </div>
        )}
      </div>
    </div>
  );
}
