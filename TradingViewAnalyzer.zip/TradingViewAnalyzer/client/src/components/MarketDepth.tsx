import { type OrderBook } from "@shared/schema";

interface MarketDepthProps {
  symbol: string;
  orderBook?: OrderBook;
  currentPrice?: number;
}

export default function MarketDepth({ symbol, orderBook, currentPrice }: MarketDepthProps) {
  // Mock order book data if not provided
  const mockOrderBook = {
    asks: [
      { price: 246.50, quantity: 250, orders: 12 },
      { price: 246.25, quantity: 180, orders: 8 },
      { price: 246.00, quantity: 320, orders: 15 },
      { price: 245.75, quantity: 95, orders: 5 },
      { price: 245.50, quantity: 200, orders: 9 },
    ],
    bids: [
      { price: 245.25, quantity: 420, orders: 18 },
      { price: 245.00, quantity: 285, orders: 11 },
      { price: 244.75, quantity: 150, orders: 6 },
      { price: 244.50, quantity: 380, orders: 16 },
      { price: 244.25, quantity: 220, orders: 10 },
    ]
  };

  const displayOrderBook = orderBook || mockOrderBook;
  const displayPrice = currentPrice || 245.50;

  return (
    <div className="h-full overflow-auto bg-slate-800">
      <div className="p-4">
        {/* Market Depth Grid */}
        <div className="grid grid-cols-2 gap-4 h-full">
          {/* Sell Orders (Left) */}
          <div className="space-y-2">
            <div className="text-xs font-semibold text-red-400 mb-3 border-b border-slate-600 pb-2">SELL ORDERS</div>
            <div className="grid grid-cols-3 gap-2 text-xs font-medium text-slate-400 mb-2">
              <div>Price</div>
              <div className="text-right">Qty</div>
              <div className="text-right">Orders</div>
            </div>
            {displayOrderBook.asks.slice(0, 5).reverse().map((order, index) => (
              <div key={`ask-${index}`} className="grid grid-cols-3 gap-2 text-xs font-mono hover:bg-slate-700 rounded px-2 py-1 transition-colors">
                <div className="text-red-400 font-semibold">₹{order.price.toFixed(2)}</div>
                <div className="text-right text-slate-300">{order.quantity}</div>
                <div className="text-right text-slate-400">{order.orders}</div>
              </div>
            ))}
          </div>

          {/* Buy Orders (Right) */}
          <div className="space-y-2">
            <div className="text-xs font-semibold text-emerald-400 mb-3 border-b border-slate-600 pb-2">BUY ORDERS</div>
            <div className="grid grid-cols-3 gap-2 text-xs font-medium text-slate-400 mb-2">
              <div>Price</div>
              <div className="text-right">Qty</div>
              <div className="text-right">Orders</div>
            </div>
            {displayOrderBook.bids.slice(0, 5).map((order, index) => (
              <div key={`bid-${index}`} className="grid grid-cols-3 gap-2 text-xs font-mono hover:bg-slate-700 rounded px-2 py-1 transition-colors">
                <div className="text-emerald-400 font-semibold">₹{order.price.toFixed(2)}</div>
                <div className="text-right text-slate-300">{order.quantity}</div>
                <div className="text-right text-slate-400">{order.orders}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Current Price Display */}
        <div className="mt-4 bg-slate-900 rounded-lg px-4 py-3 border border-slate-600">
          <div className="text-center">
            <div className="text-white font-mono font-bold text-lg">₹{displayPrice.toFixed(2)}</div>
            <div className="text-emerald-400 text-sm font-medium">+2.30 (+0.95%)</div>
            <div className="text-slate-400 text-xs mt-1">Last Traded Price</div>
          </div>
        </div>
      </div>
    </div>
  );
}
