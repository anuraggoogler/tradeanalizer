import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { type LiveMarketData } from "@shared/schema";

interface OrderPanelProps {
  symbol: string;
  marketData?: LiveMarketData;
  isConnected: boolean;
}

interface Position {
  id: string;
  symbol: string;
  side: 'BUY' | 'SELL';
  quantity: number;
  avgPrice: number;
  currentPrice: number;
  pnl: number;
  pnlPercent: number;
}

interface PendingOrder {
  id: string;
  symbol: string;
  type: string;
  side: 'BUY' | 'SELL';
  quantity: number;
  price: number;
  status: 'PENDING' | 'PARTIAL' | 'FILLED';
}

export default function OrderPanel({ symbol, marketData, isConnected }: OrderPanelProps) {
  const [orderType, setOrderType] = useState("MARKET");
  const [side, setSide] = useState<'BUY' | 'SELL'>('BUY');
  const [quantity, setQuantity] = useState(25);
  const [price, setPrice] = useState(marketData?.ltp || 0);
  const [stopLoss, setStopLoss] = useState(0);
  const [takeProfit, setTakeProfit] = useState(0);
  const [quickTradeMode, setQuickTradeMode] = useState(false);
  const [riskAmount, setRiskAmount] = useState(5000);
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Mock positions and orders for demonstration
  const [positions, setPositions] = useState<Position[]>([
    {
      id: '1',
      symbol: 'NIFTY25MAR25_18500_CE',
      side: 'BUY',
      quantity: 25,
      avgPrice: 245.50,
      currentPrice: 248.75,
      pnl: 81.25,
      pnlPercent: 1.32
    },
    {
      id: '2',
      symbol: 'BANKNIFTY25MAR25_45000_PE',
      side: 'SELL',
      quantity: 15,
      avgPrice: 380.25,
      currentPrice: 385.50,
      pnl: -78.75,
      pnlPercent: -1.38
    }
  ]);

  const [pendingOrders, setPendingOrders] = useState<PendingOrder[]>([
    {
      id: '1',
      symbol: 'NIFTY25MAR25_18400_CE',
      type: 'LIMIT',
      side: 'BUY',
      quantity: 50,
      price: 195.00,
      status: 'PENDING'
    }
  ]);

  // Update price when market data changes
  useEffect(() => {
    if (marketData && orderType === 'MARKET') {
      setPrice(marketData.ltp);
    }
  }, [marketData, orderType]);

  // Calculate position size based on risk amount
  const calculatePositionSize = () => {
    if (!marketData?.ltp) return quantity;
    return Math.floor(riskAmount / marketData.ltp);
  };

  // Calculate potential P&L
  const calculatePotentialPnL = () => {
    if (!marketData?.ltp || !price) return 0;
    const pnl = side === 'BUY' ? (price - marketData.ltp) * quantity : (marketData.ltp - price) * quantity;
    return pnl;
  };

  // Handle order placement
  const handlePlaceOrder = () => {
    const newOrder: PendingOrder = {
      id: Date.now().toString(),
      symbol,
      type: orderType,
      side,
      quantity,
      price: orderType === 'MARKET' ? (marketData?.ltp || 0) : price,
      status: 'PENDING'
    };
    
    setPendingOrders(prev => [...prev, newOrder]);
    
    // Simulate order execution for demo
    setTimeout(() => {
      setPendingOrders(prev => prev.filter(order => order.id !== newOrder.id));
      
      const newPosition: Position = {
        id: Date.now().toString(),
        symbol,
        side,
        quantity,
        avgPrice: newOrder.price,
        currentPrice: marketData?.ltp || newOrder.price,
        pnl: 0,
        pnlPercent: 0
      };
      
      setPositions(prev => [...prev, newPosition]);
    }, 2000);
  };

  // Quick trade buttons
  const handleQuickTrade = (tradeSide: 'BUY' | 'SELL', qty: number) => {
    setSide(tradeSide);
    setQuantity(qty);
    setOrderType('MARKET');
    handlePlaceOrder();
  };

  return (
    <div className="w-80 bg-slate-900 border-l border-slate-700 flex flex-col">
      {/* Header */}
      <div className="h-14 bg-slate-800 border-b border-slate-700 flex items-center justify-between px-4">
        <div className="flex items-center gap-3">
          <div className="w-6 h-6 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
            <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
          </div>
          <h3 className="text-white font-semibold">Order Panel</h3>
        </div>
        <div className={`flex items-center gap-2 ${isConnected ? 'text-green-400' : 'text-red-400'}`}>
          <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-400' : 'bg-red-400'}`}></div>
          <span className="text-xs">{isConnected ? 'Live' : 'Offline'}</span>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <Tabs defaultValue="order" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-slate-800 border-b border-slate-700">
            <TabsTrigger value="order" className="text-xs">Place Order</TabsTrigger>
            <TabsTrigger value="positions" className="text-xs">Positions</TabsTrigger>
            <TabsTrigger value="orders" className="text-xs">Orders</TabsTrigger>
          </TabsList>

          {/* Place Order Tab */}
          <TabsContent value="order" className="p-4 space-y-4">
            {/* Quick Trade Mode Toggle */}
            <div className="flex items-center justify-between">
              <Label className="text-sm text-slate-300">Quick Trade Mode</Label>
              <Switch 
                checked={quickTradeMode} 
                onCheckedChange={setQuickTradeMode}
              />
            </div>

            {quickTradeMode ? (
              /* Quick Trade Interface */
              <div className="space-y-4">
                <div className="bg-slate-800 p-4 rounded-lg border border-slate-600">
                  <div className="text-center mb-4">
                    <div className="text-2xl font-mono text-white">₹{marketData?.ltp || 0}</div>
                    <div className={`text-sm ${(marketData?.change || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {(marketData?.change || 0) >= 0 ? '+' : ''}₹{marketData?.change || 0} ({marketData?.changePercent || 0}%)
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 mb-4">
                    <Button 
                      onClick={() => handleQuickTrade('BUY', 25)}
                      className="bg-green-600 hover:bg-green-700 text-white"
                    >
                      BUY 25
                    </Button>
                    <Button 
                      onClick={() => handleQuickTrade('SELL', 25)}
                      className="bg-red-600 hover:bg-red-700 text-white"
                    >
                      SELL 25
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <Button 
                      onClick={() => handleQuickTrade('BUY', 50)}
                      variant="outline"
                      className="border-green-600 text-green-400 hover:bg-green-600 hover:text-white"
                    >
                      BUY 50
                    </Button>
                    <Button 
                      onClick={() => handleQuickTrade('SELL', 50)}
                      variant="outline"
                      className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
                    >
                      SELL 50
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              /* Advanced Order Interface */
              <div className="space-y-4">
                {/* Order Type */}
                <div>
                  <Label className="text-sm text-slate-300 mb-2 block">Order Type</Label>
                  <Select value={orderType} onValueChange={setOrderType}>
                    <SelectTrigger className="bg-slate-800 border-slate-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MARKET">Market Order</SelectItem>
                      <SelectItem value="LIMIT">Limit Order</SelectItem>
                      <SelectItem value="STOP_LOSS">Stop Loss</SelectItem>
                      <SelectItem value="BRACKET">Bracket Order</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Buy/Sell Toggle */}
                <div className="grid grid-cols-2 gap-2">
                  <Button 
                    onClick={() => setSide('BUY')}
                    className={`${side === 'BUY' ? 'bg-green-600 hover:bg-green-700' : 'bg-slate-700 hover:bg-slate-600'}`}
                  >
                    BUY
                  </Button>
                  <Button 
                    onClick={() => setSide('SELL')}
                    className={`${side === 'SELL' ? 'bg-red-600 hover:bg-red-700' : 'bg-slate-700 hover:bg-slate-600'}`}
                  >
                    SELL
                  </Button>
                </div>

                {/* Quantity */}
                <div>
                  <Label className="text-sm text-slate-300 mb-2 block">Quantity (Lots)</Label>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      value={quantity}
                      onChange={(e) => setQuantity(Number(e.target.value))}
                      className="bg-slate-800 border-slate-600 text-white"
                    />
                    <Button 
                      onClick={() => setQuantity(calculatePositionSize())}
                      variant="outline"
                      size="sm"
                      className="border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      Auto
                    </Button>
                  </div>
                </div>

                {/* Price (for limit orders) */}
                {orderType !== 'MARKET' && (
                  <div>
                    <Label className="text-sm text-slate-300 mb-2 block">Price</Label>
                    <Input
                      type="number"
                      step="0.05"
                      value={price}
                      onChange={(e) => setPrice(Number(e.target.value))}
                      className="bg-slate-800 border-slate-600 text-white"
                    />
                  </div>
                )}

                {/* Advanced Options Toggle */}
                <div className="flex items-center justify-between">
                  <Label className="text-sm text-slate-300">Advanced Options</Label>
                  <Switch 
                    checked={showAdvanced} 
                    onCheckedChange={setShowAdvanced}
                  />
                </div>

                {showAdvanced && (
                  <div className="space-y-3 bg-slate-800/50 p-3 rounded-lg border border-slate-600">
                    <div>
                      <Label className="text-sm text-slate-300 mb-2 block">Stop Loss</Label>
                      <Input
                        type="number"
                        step="0.05"
                        value={stopLoss}
                        onChange={(e) => setStopLoss(Number(e.target.value))}
                        placeholder="Optional"
                        className="bg-slate-800 border-slate-600 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-sm text-slate-300 mb-2 block">Take Profit</Label>
                      <Input
                        type="number"
                        step="0.05"
                        value={takeProfit}
                        onChange={(e) => setTakeProfit(Number(e.target.value))}
                        placeholder="Optional"
                        className="bg-slate-800 border-slate-600 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-sm text-slate-300 mb-2 block">Risk Amount (₹)</Label>
                      <Input
                        type="number"
                        value={riskAmount}
                        onChange={(e) => setRiskAmount(Number(e.target.value))}
                        className="bg-slate-800 border-slate-600 text-white"
                      />
                    </div>
                  </div>
                )}

                {/* Order Summary */}
                <div className="bg-slate-800/50 p-3 rounded-lg border border-slate-600">
                  <div className="text-sm space-y-1">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Order Value:</span>
                      <span className="text-white font-mono">₹{(price * quantity).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Margin Required:</span>
                      <span className="text-white font-mono">₹{Math.round(price * quantity * 0.2).toLocaleString()}</span>
                    </div>
                    {calculatePotentialPnL() !== 0 && (
                      <div className="flex justify-between">
                        <span className="text-slate-400">Potential P&L:</span>
                        <span className={`font-mono ${calculatePotentialPnL() >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {calculatePotentialPnL() >= 0 ? '+' : ''}₹{calculatePotentialPnL().toFixed(2)}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Place Order Button */}
                <Button 
                  onClick={handlePlaceOrder}
                  disabled={!isConnected}
                  className={`w-full ${side === 'BUY' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}`}
                >
                  {side} {quantity} lots @ ₹{orderType === 'MARKET' ? 'Market' : price}
                </Button>
              </div>
            )}
          </TabsContent>

          {/* Positions Tab */}
          <TabsContent value="positions" className="p-4">
            <div className="space-y-3">
              {positions.length === 0 ? (
                <div className="text-center text-slate-400 py-8">
                  <div className="text-4xl mb-2">📊</div>
                  <div>No open positions</div>
                </div>
              ) : (
                positions.map((position) => (
                  <Card key={position.id} className="bg-slate-800 border-slate-600">
                    <CardContent className="p-3">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <div className="text-sm font-medium text-white">{position.symbol.replace(/_/g, ' ')}</div>
                          <div className="text-xs text-slate-400">
                            {position.side} {position.quantity} @ ₹{position.avgPrice}
                          </div>
                        </div>
                        <Badge className={`${position.side === 'BUY' ? 'bg-green-600' : 'bg-red-600'}`}>
                          {position.side}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="text-xs text-slate-400">
                          LTP: ₹{position.currentPrice}
                        </div>
                        <div className={`text-sm font-mono ${position.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {position.pnl >= 0 ? '+' : ''}₹{position.pnl} ({position.pnlPercent >= 0 ? '+' : ''}{position.pnlPercent}%)
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          {/* Orders Tab */}
          <TabsContent value="orders" className="p-4">
            <div className="space-y-3">
              {pendingOrders.length === 0 ? (
                <div className="text-center text-slate-400 py-8">
                  <div className="text-4xl mb-2">📋</div>
                  <div>No pending orders</div>
                </div>
              ) : (
                pendingOrders.map((order) => (
                  <Card key={order.id} className="bg-slate-800 border-slate-600">
                    <CardContent className="p-3">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <div className="text-sm font-medium text-white">{order.symbol.replace(/_/g, ' ')}</div>
                          <div className="text-xs text-slate-400">
                            {order.type} {order.side} {order.quantity} @ ₹{order.price}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-yellow-400 border-yellow-400">
                            {order.status}
                          </Badge>
                          <button className="text-red-400 hover:text-red-300">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                          </button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer with account summary */}
      <div className="h-16 bg-slate-800 border-t border-slate-700 p-4">
        <div className="flex justify-between text-xs">
          <div>
            <div className="text-slate-400">Available</div>
            <div className="text-green-400 font-mono">₹85,350</div>
          </div>
          <div>
            <div className="text-slate-400">Margin Used</div>
            <div className="text-yellow-400 font-mono">₹14,650</div>
          </div>
          <div>
            <div className="text-slate-400">Day P&L</div>
            <div className="text-green-400 font-mono">+₹2,340</div>
          </div>
        </div>
      </div>
    </div>
  );
}