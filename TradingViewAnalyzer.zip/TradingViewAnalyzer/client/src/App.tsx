import { useState } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import Landing from "@/pages/landing";
import Home from "@/pages/home";
import TradingPage from "@/pages/trading";
import PineScriptPage from "@/pages/pinescript";
import WatchlistPage from "@/pages/watchlist";
import RiskToolsPage from "@/pages/risk";
import AlertsPage from "@/pages/alerts";
import HistoryPage from "@/pages/history";
import SettingsPage from "@/pages/settings";
import NotFound from "@/pages/not-found";
import NavigationSidebar from "@/components/NavigationSidebar";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [sidebarAutoHide, setSidebarAutoHide] = useState(true);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-white text-xl">Loading TradeMaster Pro...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Landing />;
  }

  return (
    <div className="h-screen bg-slate-950 flex relative">
      <NavigationSidebar
        isCollapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        autoHide={sidebarAutoHide}
        onToggleAutoHide={() => setSidebarAutoHide(!sidebarAutoHide)}
      />
      <div className={`flex-1 flex flex-col transition-all duration-300 ease-in-out ${
        sidebarAutoHide ? 'ml-16' : (sidebarCollapsed ? 'ml-16' : 'ml-64')
      }`}>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/trading" component={TradingPage} />
          <Route path="/pinescript" component={PineScriptPage} />
          <Route path="/watchlist" component={WatchlistPage} />
          <Route path="/risk" component={RiskToolsPage} />
          <Route path="/alerts" component={AlertsPage} />
          <Route path="/history" component={HistoryPage} />
          <Route path="/settings" component={SettingsPage} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="dark">
          <Toaster />
          <Router />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
