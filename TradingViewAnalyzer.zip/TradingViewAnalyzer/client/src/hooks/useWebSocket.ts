import { useEffect, useRef, useState } from "react";

interface WebSocketHook {
  isConnected: boolean;
  subscribe: (symbols: string[]) => void;
  unsubscribe: (symbols: string[]) => void;
  lastMessage: any;
}

export function useWebSocket(): WebSocketHook {
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<any>(null);
  const ws = useRef<WebSocket | null>(null);
  const subscribedSymbols = useRef<Set<string>>(new Set());

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const connect = () => {
      try {
        ws.current = new WebSocket(wsUrl);

        ws.current.onopen = () => {
          setIsConnected(true);
          console.log('WebSocket connected');
          
          // Resubscribe to symbols after reconnection
          if (subscribedSymbols.current.size > 0) {
            ws.current?.send(JSON.stringify({
              type: 'subscribe',
              symbols: Array.from(subscribedSymbols.current)
            }));
          }
        };

        ws.current.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            setLastMessage(data);
          } catch (error) {
            console.error('Error parsing WebSocket message:', error);
          }
        };

        ws.current.onclose = () => {
          setIsConnected(false);
          console.log('WebSocket disconnected');
          
          // Only reconnect if component is still mounted
          if (ws.current) {
            setTimeout(connect, 5000);
          }
        };

        ws.current.onerror = (error) => {
          console.error('WebSocket error:', error);
          setIsConnected(false);
        };
      } catch (error) {
        console.error('Error creating WebSocket connection:', error);
        setIsConnected(false);
        
        // Retry connection after 5 seconds
        setTimeout(connect, 5000);
      }
    };

    connect();

    return () => {
      if (ws.current) {
        ws.current.close();
      }
    };
  }, []);

  const subscribe = (symbols: string[]) => {
    symbols.forEach(symbol => subscribedSymbols.current.add(symbol));
    
    if (ws.current && ws.current.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify({
        type: 'subscribe',
        symbols: symbols
      }));
    }
  };

  const unsubscribe = (symbols: string[]) => {
    symbols.forEach(symbol => subscribedSymbols.current.delete(symbol));
    
    if (ws.current && ws.current.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify({
        type: 'unsubscribe',
        symbols: symbols
      }));
    }
  };

  return {
    isConnected,
    subscribe,
    unsubscribe,
    lastMessage
  };
}
