import { useState, useEffect } from "react";
import { useWebSocket } from "./useWebSocket";
import { type LiveMarketData, type OrderBook } from "@shared/schema";

interface MarketDataHook {
  marketData: LiveMarketData | null;
  orderBook: OrderBook | null;
}

export function useMarketData(symbol: string): MarketDataHook {
  const [marketData, setMarketData] = useState<LiveMarketData | null>(null);
  const [orderBook, setOrderBook] = useState<OrderBook | null>(null);
  const { lastMessage, subscribe, unsubscribe } = useWebSocket();

  useEffect(() => {
    // Subscribe to the symbol when it changes
    subscribe([symbol]);

    return () => {
      unsubscribe([symbol]);
    };
  }, [symbol, subscribe, unsubscribe]);

  useEffect(() => {
    if (lastMessage) {
      if (lastMessage.type === 'livePrice' && lastMessage.symbol === symbol) {
        setMarketData(lastMessage.data);
      } else if (lastMessage.type === 'orderBook' && lastMessage.symbol === symbol) {
        setOrderBook(lastMessage.data);
      }
    }
  }, [lastMessage, symbol]);

  // Initialize with mock data for the symbol
  useEffect(() => {
    const mockData: LiveMarketData = {
      symbol,
      ltp: symbol.includes('18500') ? 245.50 : symbol.includes('18400') ? 128.50 : 
           symbol.includes('42000') ? 890.25 : 165.75,
      change: symbol.includes('PE') ? -5.20 : 12.30,
      changePercent: symbol.includes('PE') ? -3.89 : 5.28,
      volume: Math.floor(Math.random() * 100000) + 10000,
      openInterest: Math.floor(Math.random() * 500000) + 50000,
      bid: 0,
      ask: 0,
      timestamp: Date.now()
    };

    mockData.bid = mockData.ltp - 0.25;
    mockData.ask = mockData.ltp + 0.25;

    setMarketData(mockData);
  }, [symbol]);

  return {
    marketData,
    orderBook
  };
}
