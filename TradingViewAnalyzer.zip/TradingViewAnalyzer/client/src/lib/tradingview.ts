// TradingView charting library integration utilities

export interface TradingViewConfig {
  container: string | HTMLElement;
  symbol: string;
  interval: string;
  timezone: string;
  theme: 'light' | 'dark';
  locale: string;
  toolbar_bg: string;
  studies: string[];
  datafeed: any;
}

export interface DatafeedConfiguration {
  supported_resolutions: string[];
  exchanges: any[];
  symbols_types: any[];
}

export interface SymbolInfo {
  name: string;
  ticker: string;
  description: string;
  type: string;
  session: string;
  timezone: string;
  minmov: number;
  pricescale: number;
  has_intraday: boolean;
  supported_resolutions: string[];
  volume_precision: number;
  data_status: string;
}

export interface Bar {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export class TradingViewDatafeed {
  private symbols: Map<string, SymbolInfo> = new Map();
  private subscribers: Map<string, any> = new Map();

  constructor() {
    this.initializeSymbols();
  }

  private initializeSymbols() {
    const foSymbols = [
      'NIFTY25MAR25_18500_CE',
      'NIFTY25MAR25_18400_PE',
      'BANKNIFTY25MAR25_42000_CE',
      'FINNIFTY25MAR25_19500_CE',
    ];

    foSymbols.forEach(symbol => {
      this.symbols.set(symbol, {
        name: symbol,
        ticker: symbol,
        description: symbol.replace(/_/g, ' '),
        type: 'forex',
        session: '0915-1530',
        timezone: 'Asia/Kolkata',
        minmov: 1,
        pricescale: 100,
        has_intraday: true,
        supported_resolutions: ['1', '5', '15', '60', '1D'],
        volume_precision: 0,
        data_status: 'streaming'
      });
    });
  }

  onReady(callback: (config: DatafeedConfiguration) => void) {
    setTimeout(() => {
      callback({
        exchanges: [],
        symbols_types: [],
        supported_resolutions: ['1', '5', '15', '60', '1D']
      });
    }, 0);
  }

  searchSymbols(
    userInput: string,
    exchange: string,
    symbolType: string,
    onResultReadyCallback: (symbols: any[]) => void
  ) {
    const results = Array.from(this.symbols.values())
      .filter(symbol => 
        symbol.name.toLowerCase().includes(userInput.toLowerCase())
      )
      .map(symbol => ({
        symbol: symbol.name,
        full_name: symbol.description,
        description: symbol.description,
        exchange: 'NSE',
        ticker: symbol.ticker,
        type: symbol.type
      }));

    onResultReadyCallback(results);
  }

  resolveSymbol(
    symbolName: string,
    onSymbolResolvedCallback: (symbolInfo: SymbolInfo) => void,
    onResolveErrorCallback: (reason: string) => void
  ) {
    const symbolInfo = this.symbols.get(symbolName);
    
    if (symbolInfo) {
      onSymbolResolvedCallback(symbolInfo);
    } else {
      onResolveErrorCallback('Symbol not found');
    }
  }

  getBars(
    symbolInfo: SymbolInfo,
    resolution: string,
    periodParams: any,
    onHistoryCallback: (bars: Bar[], meta: any) => void,
    onErrorCallback: (error: any) => void
  ) {
    // Generate mock historical data
    const bars = this.generateMockBars(symbolInfo.name, periodParams.from, periodParams.to, resolution);
    
    onHistoryCallback(bars, { noData: bars.length === 0 });
  }

  subscribeBars(
    symbolInfo: SymbolInfo,
    resolution: string,
    onRealtimeCallback: (bar: Bar) => void,
    subscriberUID: string,
    onResetCacheNeededCallback: () => void
  ) {
    this.subscribers.set(subscriberUID, {
      symbolInfo,
      resolution,
      onRealtimeCallback,
      onResetCacheNeededCallback
    });

    // Start real-time data simulation
    this.startRealtimeSimulation(subscriberUID);
  }

  unsubscribeBars(subscriberUID: string) {
    this.subscribers.delete(subscriberUID);
  }

  private generateMockBars(symbol: string, from: number, to: number, resolution: string): Bar[] {
    const bars: Bar[] = [];
    const basePrice = this.getBasePrice(symbol);
    const timeFrame = this.getTimeFrameMs(resolution);
    
    let currentTime = from * 1000;
    let currentPrice = basePrice;
    
    while (currentTime <= to * 1000) {
      const volatility = 0.02;
      const change = (Math.random() - 0.5) * volatility * currentPrice;
      
      const open = currentPrice;
      const close = Math.max(0.05, currentPrice + change);
      const high = Math.max(open, close) * (1 + Math.random() * 0.01);
      const low = Math.min(open, close) * (1 - Math.random() * 0.01);
      const volume = Math.floor(Math.random() * 10000) + 1000;

      bars.push({
        time: currentTime,
        open,
        high,
        low,
        close,
        volume
      });

      currentPrice = close;
      currentTime += timeFrame;
    }

    return bars;
  }

  private getBasePrice(symbol: string): number {
    const basePrices: Record<string, number> = {
      'NIFTY25MAR25_18500_CE': 245.50,
      'NIFTY25MAR25_18400_PE': 128.50,
      'BANKNIFTY25MAR25_42000_CE': 890.25,
      'FINNIFTY25MAR25_19500_CE': 165.75,
    };
    
    return basePrices[symbol] || 100;
  }

  private getTimeFrameMs(resolution: string): number {
    const timeFrames: Record<string, number> = {
      '1': 60 * 1000,      // 1 minute
      '5': 5 * 60 * 1000,  // 5 minutes
      '15': 15 * 60 * 1000, // 15 minutes
      '60': 60 * 60 * 1000, // 1 hour
      '1D': 24 * 60 * 60 * 1000 // 1 day
    };
    
    return timeFrames[resolution] || 60 * 1000;
  }

  private startRealtimeSimulation(subscriberUID: string) {
    const subscriber = this.subscribers.get(subscriberUID);
    if (!subscriber) return;

    const interval = setInterval(() => {
      if (!this.subscribers.has(subscriberUID)) {
        clearInterval(interval);
        return;
      }

      const currentTime = Date.now();
      const basePrice = this.getBasePrice(subscriber.symbolInfo.name);
      const volatility = 0.001;
      const change = (Math.random() - 0.5) * volatility * basePrice;
      
      const price = Math.max(0.05, basePrice + change);
      const volume = Math.floor(Math.random() * 1000) + 100;

      const bar: Bar = {
        time: currentTime,
        open: price,
        high: price * (1 + Math.random() * 0.001),
        low: price * (1 - Math.random() * 0.001),
        close: price,
        volume
      };

      subscriber.onRealtimeCallback(bar);
    }, 1000); // Update every second
  }
}

export function createTradingViewWidget(config: TradingViewConfig) {
  return new Promise((resolve, reject) => {
    // In a real implementation, this would load the TradingView library
    // and create the widget. For now, we'll simulate this.
    
    setTimeout(() => {
      const widget = {
        chart: () => ({
          setSymbol: (symbol: string) => {
            console.log('Setting symbol:', symbol);
          },
          setResolution: (resolution: string) => {
            console.log('Setting resolution:', resolution);
          }
        }),
        remove: () => {
          console.log('Widget removed');
        }
      };
      
      resolve(widget);
    }, 100);
  });
}
