// Pine Script utilities for parsing, validation, and execution
import { type PineScript, type PineScriptSignal } from "@shared/schema";

export interface PineScriptValidationError {
  line: number;
  column: number;
  message: string;
  type: 'syntax' | 'semantic' | 'runtime';
}

export interface PineScriptValidationResult {
  isValid: boolean;
  errors: PineScriptValidationError[];
  warnings: PineScriptValidationError[];
}

export interface PineScriptIndicator {
  name: string;
  type: 'overlay' | 'oscillator' | 'volume';
  parameters: Record<string, any>;
  formula: string;
}

export interface PineScriptStrategy {
  name: string;
  entryConditions: string[];
  exitConditions: string[];
  riskManagement: {
    stopLoss?: number;
    takeProfit?: number;
    positionSize?: number;
  };
}

export interface PineScriptExecutionContext {
  symbol: string;
  timeframe: string;
  historicalData: any[];
  currentPrice: number;
  volume: number;
  timestamp: number;
}

export interface PineScriptExecutionResult {
  success: boolean;
  signals: PineScriptSignal[];
  indicators: Record<string, number>;
  plots: Array<{
    name: string;
    value: number;
    color: string;
    style: 'line' | 'histogram' | 'cross';
  }>;
  error?: string;
  executionTime: number;
}

export class PineScriptParser {
  private static readonly PINE_SCRIPT_VERSION_REGEX = /\/\/\s*@version\s*=\s*(\d+)/;
  private static readonly FUNCTION_REGEX = /(\w+)\s*\(/g;
  private static readonly VARIABLE_REGEX = /(\w+)\s*=/g;
  private static readonly STRATEGY_REGEX = /strategy\s*\(/;
  private static readonly INDICATOR_REGEX = /indicator\s*\(/;

  static validatePineScript(code: string): PineScriptValidationResult {
    const errors: PineScriptValidationError[] = [];
    const warnings: PineScriptValidationError[] = [];
    const lines = code.split('\n');

    // Check for Pine Script version
    const versionMatch = code.match(this.PINE_SCRIPT_VERSION_REGEX);
    if (!versionMatch) {
      errors.push({
        line: 1,
        column: 1,
        message: 'Pine Script version declaration is required (e.g., // @version=6)',
        type: 'syntax'
      });
    } else {
      const version = parseInt(versionMatch[1]);
      if (version < 5) {
        warnings.push({
          line: 1,
          column: 1,
          message: `Pine Script v${version} is deprecated. Consider upgrading to v6`,
          type: 'semantic'
        });
      }
    }

    // Check for strategy or indicator declaration
    const hasStrategy = this.STRATEGY_REGEX.test(code);
    const hasIndicator = this.INDICATOR_REGEX.test(code);

    if (!hasStrategy && !hasIndicator) {
      errors.push({
        line: 2,
        column: 1,
        message: 'Script must contain either strategy() or indicator() declaration',
        type: 'semantic'
      });
    }

    // Validate syntax for common Pine Script functions
    lines.forEach((line, index) => {
      const lineNumber = index + 1;
      
      // Check for common syntax errors
      if (line.includes('=') && !line.includes('==') && !line.includes('!=') && !line.includes('>=') && !line.includes('<=')) {
        const assignmentMatch = line.match(/(\w+)\s*=\s*(.+)/);
        if (assignmentMatch) {
          const varName = assignmentMatch[1];
          const value = assignmentMatch[2].trim();
          
          // Check for undefined function calls
          if (value.includes('ta.') && !this.isValidTechnicalAnalysisFunction(value)) {
            errors.push({
              line: lineNumber,
              column: line.indexOf(value),
              message: `Unknown technical analysis function in: ${value}`,
              type: 'semantic'
            });
          }
        }
      }

      // Check for missing semicolons in certain contexts
      if (line.includes('strategy.entry') || line.includes('strategy.exit')) {
        if (!line.trim().endsWith(')') && !line.trim().endsWith('}')) {
          warnings.push({
            line: lineNumber,
            column: line.length,
            message: 'Consider proper line termination for strategy functions',
            type: 'syntax'
          });
        }
      }

      // Check for deprecated functions
      const deprecatedFunctions = ['security', 'study'];
      deprecatedFunctions.forEach(func => {
        if (line.includes(func + '(')) {
          warnings.push({
            line: lineNumber,
            column: line.indexOf(func),
            message: `Function '${func}' is deprecated. Use modern alternatives`,
            type: 'semantic'
          });
        }
      });
    });

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }

  private static isValidTechnicalAnalysisFunction(expression: string): boolean {
    const validTaFunctions = [
      'ta.sma', 'ta.ema', 'ta.rsi', 'ta.macd', 'ta.bb', 'ta.stoch',
      'ta.atr', 'ta.roc', 'ta.cci', 'ta.mom', 'ta.obv', 'ta.ad',
      'ta.adx', 'ta.aroon', 'ta.sar', 'ta.tsi', 'ta.wpr', 'ta.mfi',
      'ta.vwma', 'ta.swma', 'ta.alma', 'ta.hma', 'ta.linreg',
      'ta.correlation', 'ta.dev', 'ta.variance', 'ta.stdev'
    ];

    return validTaFunctions.some(func => expression.includes(func));
  }

  static extractIndicators(code: string): PineScriptIndicator[] {
    const indicators: PineScriptIndicator[] = [];
    const lines = code.split('\n');

    lines.forEach(line => {
      // Extract technical analysis indicators
      const taMatches = line.match(/(\w+)\s*=\s*ta\.(\w+)\s*\(([^)]*)\)/);
      if (taMatches) {
        const [, varName, funcName, params] = taMatches;
        indicators.push({
          name: varName,
          type: this.getIndicatorType(funcName),
          parameters: this.parseParameters(params),
          formula: `ta.${funcName}`
        });
      }

      // Extract plot statements
      const plotMatches = line.match(/plot\s*\(\s*([^,]+),?\s*([^)]*)\)/);
      if (plotMatches) {
        const [, value, options] = plotMatches;
        indicators.push({
          name: `plot_${value}`,
          type: 'overlay',
          parameters: this.parseParameters(options || ''),
          formula: `plot(${value})`
        });
      }
    });

    return indicators;
  }

  private static getIndicatorType(funcName: string): 'overlay' | 'oscillator' | 'volume' {
    const oscillators = ['rsi', 'macd', 'stoch', 'cci', 'mfi', 'wpr', 'tsi'];
    const volumeIndicators = ['obv', 'ad', 'mfi'];
    
    if (oscillators.includes(funcName)) return 'oscillator';
    if (volumeIndicators.includes(funcName)) return 'volume';
    return 'overlay';
  }

  private static parseParameters(paramString: string): Record<string, any> {
    const params: Record<string, any> = {};
    
    if (!paramString.trim()) return params;

    const paramPairs = paramString.split(',');
    paramPairs.forEach(pair => {
      const [key, value] = pair.split('=').map(s => s.trim());
      if (key && value) {
        // Try to parse as number, otherwise keep as string
        const numValue = parseFloat(value);
        params[key] = isNaN(numValue) ? value.replace(/['"]/g, '') : numValue;
      }
    });

    return params;
  }

  static extractStrategy(code: string): PineScriptStrategy | null {
    const strategyMatch = code.match(/strategy\s*\(\s*"([^"]+)"/);
    if (!strategyMatch) return null;

    const strategyName = strategyMatch[1];
    const entryConditions: string[] = [];
    const exitConditions: string[] = [];

    const lines = code.split('\n');
    lines.forEach(line => {
      if (line.includes('strategy.entry')) {
        const condition = this.extractConditionFromStrategyCall(line);
        if (condition) entryConditions.push(condition);
      }
      
      if (line.includes('strategy.exit') || line.includes('strategy.close')) {
        const condition = this.extractConditionFromStrategyCall(line);
        if (condition) exitConditions.push(condition);
      }
    });

    return {
      name: strategyName,
      entryConditions,
      exitConditions,
      riskManagement: this.extractRiskManagement(code)
    };
  }

  private static extractConditionFromStrategyCall(line: string): string | null {
    // Look for if statements or when conditions
    const ifMatch = line.match(/if\s*\(\s*([^)]+)\)/);
    if (ifMatch) return ifMatch[1];

    const whenMatch = line.match(/when\s*=\s*([^,)]+)/);
    if (whenMatch) return whenMatch[1];

    return null;
  }

  private static extractRiskManagement(code: string): PineScriptStrategy['riskManagement'] {
    const riskManagement: PineScriptStrategy['riskManagement'] = {};

    // Look for stop loss settings
    const stopLossMatch = code.match(/stop\s*=\s*([^,)]+)/);
    if (stopLossMatch) {
      const stopValue = parseFloat(stopLossMatch[1]);
      if (!isNaN(stopValue)) riskManagement.stopLoss = stopValue;
    }

    // Look for take profit settings
    const takeProfitMatch = code.match(/limit\s*=\s*([^,)]+)/);
    if (takeProfitMatch) {
      const limitValue = parseFloat(takeProfitMatch[1]);
      if (!isNaN(limitValue)) riskManagement.takeProfit = limitValue;
    }

    // Look for position size settings
    const qtyMatch = code.match(/qty\s*=\s*([^,)]+)/);
    if (qtyMatch) {
      const qtyValue = parseFloat(qtyMatch[1]);
      if (!isNaN(qtyValue)) riskManagement.positionSize = qtyValue;
    }

    return riskManagement;
  }
}

export class PineScriptExecutor {
  static async executeScript(
    script: PineScript,
    context: PineScriptExecutionContext
  ): Promise<PineScriptExecutionResult> {
    const startTime = Date.now();
    
    try {
      // Validate the script first
      const validation = PineScriptParser.validatePineScript(script.code);
      if (!validation.isValid) {
        return {
          success: false,
          signals: [],
          indicators: {},
          plots: [],
          error: validation.errors.map(e => e.message).join('; '),
          executionTime: Date.now() - startTime
        };
      }

      // Extract indicators and strategy
      const indicators = PineScriptParser.extractIndicators(script.code);
      const strategy = PineScriptParser.extractStrategy(script.code);

      // Calculate indicator values
      const indicatorValues = this.calculateIndicators(indicators, context);
      
      // Generate signals based on strategy
      const signals = strategy ? this.generateSignals(strategy, indicatorValues, context) : [];

      // Generate plots for visualization
      const plots = this.generatePlots(indicators, indicatorValues);

      return {
        success: true,
        signals,
        indicators: indicatorValues,
        plots,
        executionTime: Date.now() - startTime
      };
    } catch (error) {
      return {
        success: false,
        signals: [],
        indicators: {},
        plots: [],
        error: error instanceof Error ? error.message : 'Unknown execution error',
        executionTime: Date.now() - startTime
      };
    }
  }

  private static calculateIndicators(
    indicators: PineScriptIndicator[],
    context: PineScriptExecutionContext
  ): Record<string, number> {
    const values: Record<string, number> = {};

    indicators.forEach(indicator => {
      switch (indicator.formula) {
        case 'ta.rsi':
          values[indicator.name] = this.calculateRSI(context.currentPrice, indicator.parameters.length || 14);
          break;
        case 'ta.sma':
          values[indicator.name] = this.calculateSMA(context.currentPrice, indicator.parameters.length || 20);
          break;
        case 'ta.ema':
          values[indicator.name] = this.calculateEMA(context.currentPrice, indicator.parameters.length || 20);
          break;
        case 'ta.macd':
          const macd = this.calculateMACD(context.currentPrice);
          values[`${indicator.name}_line`] = macd.line;
          values[`${indicator.name}_signal`] = macd.signal;
          values[`${indicator.name}_histogram`] = macd.histogram;
          break;
        case 'ta.bb':
          const bb = this.calculateBollingerBands(context.currentPrice, indicator.parameters.length || 20);
          values[`${indicator.name}_upper`] = bb.upper;
          values[`${indicator.name}_middle`] = bb.middle;
          values[`${indicator.name}_lower`] = bb.lower;
          break;
        default:
          values[indicator.name] = context.currentPrice;
      }
    });

    return values;
  }

  private static calculateRSI(currentPrice: number, period: number = 14): number {
    // Simplified RSI calculation for demo
    // In production, this would use historical price data
    const random = Math.random();
    if (random < 0.15) return Math.random() * 30; // Oversold
    if (random > 0.85) return 70 + Math.random() * 30; // Overbought
    return 30 + Math.random() * 40; // Normal range
  }

  private static calculateSMA(currentPrice: number, period: number = 20): number {
    // Simplified SMA calculation
    return currentPrice * (0.98 + Math.random() * 0.04);
  }

  private static calculateEMA(currentPrice: number, period: number = 20): number {
    // Simplified EMA calculation
    return currentPrice * (0.99 + Math.random() * 0.02);
  }

  private static calculateMACD(currentPrice: number) {
    const ema12 = this.calculateEMA(currentPrice, 12);
    const ema26 = this.calculateEMA(currentPrice, 26);
    const line = ema12 - ema26;
    const signal = line * 0.9; // Simplified signal line
    const histogram = line - signal;

    return { line, signal, histogram };
  }

  private static calculateBollingerBands(currentPrice: number, period: number = 20) {
    const sma = this.calculateSMA(currentPrice, period);
    const deviation = currentPrice * 0.02; // 2% standard deviation approximation
    
    return {
      upper: sma + (2 * deviation),
      middle: sma,
      lower: sma - (2 * deviation)
    };
  }

  private static generateSignals(
    strategy: PineScriptStrategy,
    indicators: Record<string, number>,
    context: PineScriptExecutionContext
  ): PineScriptSignal[] {
    const signals: PineScriptSignal[] = [];

    // Evaluate entry conditions
    strategy.entryConditions.forEach(condition => {
      const signal = this.evaluateCondition(condition, indicators, context);
      if (signal) {
        signals.push(signal);
      }
    });

    return signals;
  }

  private static evaluateCondition(
    condition: string,
    indicators: Record<string, number>,
    context: PineScriptExecutionContext
  ): PineScriptSignal | null {
    // Simple condition evaluation for common patterns
    
    // RSI oversold/overbought
    if (condition.includes('rsi_value < rsi_oversold') || condition.includes('rsi_value < 30')) {
      const rsi = indicators.rsi_value || indicators.rsi || 50;
      if (rsi < 30) {
        return {
          symbol: context.symbol,
          action: 'BUY',
          price: context.currentPrice,
          quantity: 1,
          timestamp: context.timestamp,
          strategy: 'RSI Oversold',
          confidence: 0.8
        };
      }
    }

    if (condition.includes('rsi_value > rsi_overbought') || condition.includes('rsi_value > 70')) {
      const rsi = indicators.rsi_value || indicators.rsi || 50;
      if (rsi > 70) {
        return {
          symbol: context.symbol,
          action: 'SELL',
          price: context.currentPrice,
          quantity: 1,
          timestamp: context.timestamp,
          strategy: 'RSI Overbought',
          confidence: 0.8
        };
      }
    }

    // Moving average crossover
    if (condition.includes('ta.crossover')) {
      return {
        symbol: context.symbol,
        action: 'BUY',
        price: context.currentPrice,
        quantity: 1,
        timestamp: context.timestamp,
        strategy: 'MA Crossover',
        confidence: 0.7
      };
    }

    return null;
  }

  private static generatePlots(
    indicators: PineScriptIndicator[],
    values: Record<string, number>
  ): Array<{
    name: string;
    value: number;
    color: string;
    style: 'line' | 'histogram' | 'cross';
  }> {
    const plots: any[] = [];

    indicators.forEach(indicator => {
      if (indicator.name.startsWith('plot_')) {
        const value = values[indicator.name] || 0;
        plots.push({
          name: indicator.name,
          value,
          color: this.getIndicatorColor(indicator.type),
          style: 'line'
        });
      }
    });

    return plots;
  }

  private static getIndicatorColor(type: string): string {
    switch (type) {
      case 'oscillator': return '#8b5cf6'; // Purple
      case 'volume': return '#3b82f6'; // Blue
      default: return '#10b981'; // Green
    }
  }
}

export class PineScriptTemplates {
  static getBasicRSIStrategy(): string {
    return `// @version=6
strategy("Basic RSI Strategy", overlay=true, default_qty_type=strategy.percent_of_equity, default_qty_value=10)

// Input parameters
rsi_length = input.int(14, "RSI Length", minval=1)
rsi_overbought = input.int(70, "RSI Overbought Level")
rsi_oversold = input.int(30, "RSI Oversold Level")

// Calculate RSI
rsi_value = ta.rsi(close, rsi_length)

// Entry conditions
long_condition = rsi_value < rsi_oversold
short_condition = rsi_value > rsi_overbought

// Execute trades
if (long_condition)
    strategy.entry("Long", strategy.long)

if (short_condition)
    strategy.entry("Short", strategy.short)

// Plot RSI
plot(rsi_value, "RSI", color=color.purple)
hline(rsi_overbought, "Overbought", color=color.red)
hline(rsi_oversold, "Oversold", color=color.green)
hline(50, "Midline", color=color.gray)`;
  }

  static getMovingAverageCrossover(): string {
    return `// @version=6
strategy("MA Crossover Strategy", overlay=true)

// Input parameters
fast_length = input.int(9, "Fast MA Length")
slow_length = input.int(21, "Slow MA Length")

// Calculate moving averages
fast_ma = ta.sma(close, fast_length)
slow_ma = ta.sma(close, slow_length)

// Entry conditions
long_condition = ta.crossover(fast_ma, slow_ma)
short_condition = ta.crossunder(fast_ma, slow_ma)

// Execute trades
if (long_condition)
    strategy.entry("Long", strategy.long)

if (short_condition)
    strategy.entry("Short", strategy.short)

// Plot moving averages
plot(fast_ma, "Fast MA", color=color.blue)
plot(slow_ma, "Slow MA", color=color.red)`;
  }

  static getBollingerBandsStrategy(): string {
    return `// @version=6
strategy("Bollinger Bands Strategy", overlay=true)

// Input parameters
bb_length = input.int(20, "Bollinger Bands Length")
bb_mult = input.float(2.0, "Bollinger Bands Multiplier")

// Calculate Bollinger Bands
[bb_middle, bb_upper, bb_lower] = ta.bb(close, bb_length, bb_mult)

// Entry conditions
long_condition = close <= bb_lower
short_condition = close >= bb_upper

// Exit conditions
long_exit = close >= bb_middle
short_exit = close <= bb_middle

// Execute trades
if (long_condition)
    strategy.entry("Long", strategy.long)

if (short_condition)
    strategy.entry("Short", strategy.short)

if (long_exit)
    strategy.close("Long")

if (short_exit)
    strategy.close("Short")

// Plot Bollinger Bands
plot(bb_upper, "Upper Band", color=color.red)
plot(bb_middle, "Middle Band", color=color.blue)
plot(bb_lower, "Lower Band", color=color.green)`;
  }

  static getMACDStrategy(): string {
    return `// @version=6
strategy("MACD Strategy", overlay=false)

// Input parameters
fast_length = input.int(12, "MACD Fast Length")
slow_length = input.int(26, "MACD Slow Length")
signal_length = input.int(9, "MACD Signal Length")

// Calculate MACD
[macd_line, signal_line, histogram] = ta.macd(close, fast_length, slow_length, signal_length)

// Entry conditions
long_condition = ta.crossover(macd_line, signal_line)
short_condition = ta.crossunder(macd_line, signal_line)

// Execute trades
if (long_condition)
    strategy.entry("Long", strategy.long)

if (short_condition)
    strategy.entry("Short", strategy.short)

// Plot MACD
plot(macd_line, "MACD Line", color=color.blue)
plot(signal_line, "Signal Line", color=color.red)
plot(histogram, "Histogram", color=color.gray, style=plot.style_histogram)
hline(0, "Zero Line", color=color.white)`;
  }

  static getCustomIndicator(): string {
    return `// @version=6
indicator("Custom F&O Indicator", overlay=true)

// Input parameters
length = input.int(14, "Length")
multiplier = input.float(2.0, "Multiplier")

// Custom calculation
custom_value = ta.sma(close, length) + (ta.stdev(close, length) * multiplier)

// Plot the indicator
plot(custom_value, "Custom Indicator", color=color.purple, linewidth=2)

// Add alerts
alertcondition(close > custom_value, title="Price Above Indicator", message="Price crossed above custom indicator")
alertcondition(close < custom_value, title="Price Below Indicator", message="Price crossed below custom indicator")`;
  }

  static getAllTemplates(): Record<string, string> {
    return {
      'Basic RSI Strategy': this.getBasicRSIStrategy(),
      'Moving Average Crossover': this.getMovingAverageCrossover(),
      'Bollinger Bands Strategy': this.getBollingerBandsStrategy(),
      'MACD Strategy': this.getMACDStrategy(),
      'Custom Indicator': this.getCustomIndicator()
    };
  }
}

// Export utility functions
export function formatPineScriptCode(code: string): string {
  const lines = code.split('\n');
  let indentLevel = 0;
  
  return lines.map(line => {
    const trimmed = line.trim();
    
    if (trimmed.includes('}') || trimmed.includes('endif') || trimmed.includes('endfor')) {
      indentLevel = Math.max(0, indentLevel - 1);
    }
    
    const formatted = '    '.repeat(indentLevel) + trimmed;
    
    if (trimmed.includes('{') || trimmed.includes('if ') || trimmed.includes('for ')) {
      indentLevel++;
    }
    
    return formatted;
  }).join('\n');
}

export function extractPineScriptMetadata(code: string) {
  const metadata: any = {};
  
  // Extract version
  const versionMatch = code.match(/\/\/\s*@version\s*=\s*(\d+)/);
  if (versionMatch) {
    metadata.version = parseInt(versionMatch[1]);
  }
  
  // Extract title from strategy/indicator declaration
  const titleMatch = code.match(/(?:strategy|indicator)\s*\(\s*"([^"]+)"/);
  if (titleMatch) {
    metadata.title = titleMatch[1];
  }
  
  // Extract overlay setting
  metadata.overlay = code.includes('overlay=true');
  
  // Count inputs
  metadata.inputCount = (code.match(/input\./g) || []).length;
  
  // Count plots
  metadata.plotCount = (code.match(/plot\(/g) || []).length;
  
  return metadata;
}
