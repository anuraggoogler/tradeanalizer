import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function AlertsPage() {
  const alerts = [
    {
      id: 1,
      symbol: "NIFTY25MAR25_18500_CE",
      type: "Price Alert",
      condition: "Above ₹250",
      currentPrice: 248.50,
      status: "Active",
      created: "2 hours ago"
    },
    {
      id: 2,
      symbol: "BANKNIFTY25MAR25_45000_PE",
      type: "Volume Alert",
      condition: "Volume > 10,000",
      currentVolume: 8500,
      status: "Active",
      created: "1 day ago"
    },
    {
      id: 3,
      symbol: "NIFTY25MAR25_18400_CE",
      type: "Price Alert",
      condition: "Below ₹200",
      currentPrice: 195.75,
      status: "Triggered",
      created: "3 hours ago"
    }
  ];

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 text-slate-100 overflow-auto">
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-white">Price Alerts</h1>
          <Button className="bg-primary-600 hover:bg-primary-700">
            <i className="fas fa-plus mr-2"></i>
            Create Alert
          </Button>
        </div>
        
        <div className="space-y-4">
          {alerts.map((alert) => (
            <Card key={alert.id} className="bg-slate-800 border-slate-700">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div>
                      <h3 className="font-semibold text-white">{alert.symbol}</h3>
                      <p className="text-sm text-slate-400">{alert.type} - {alert.condition}</p>
                    </div>
                    <div className="text-sm">
                      <div className="text-slate-300">
                        Current: ₹{alert.currentPrice || alert.currentVolume?.toLocaleString()}
                      </div>
                      <div className="text-xs text-slate-400">{alert.created}</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Badge 
                      variant={alert.status === "Triggered" ? "destructive" : "default"}
                      className={alert.status === "Active" ? "bg-green-600" : ""}
                    >
                      {alert.status}
                    </Badge>
                    <Button variant="outline" size="sm" className="bg-slate-700 border-slate-600">
                      <i className="fas fa-edit"></i>
                    </Button>
                    <Button variant="outline" size="sm" className="bg-slate-700 border-slate-600 text-red-400">
                      <i className="fas fa-trash"></i>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}