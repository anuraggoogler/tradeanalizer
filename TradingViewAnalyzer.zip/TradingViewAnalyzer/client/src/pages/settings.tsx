import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

export default function SettingsPage() {
  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 text-slate-100 overflow-auto">
      <div className="p-6 max-w-4xl">
        <h1 className="text-2xl font-bold text-white mb-6">Settings</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Trading Preferences */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <i className="fas fa-chart-line mr-2 text-blue-500"></i>
                Trading Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="default-lot-size" className="text-slate-300">Default Lot Size</Label>
                <Input
                  id="default-lot-size"
                  type="number"
                  defaultValue={25}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              
              <div>
                <Label htmlFor="risk-percent" className="text-slate-300">Risk per Trade (%)</Label>
                <Input
                  id="risk-percent"
                  type="number"
                  defaultValue={2}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <Label htmlFor="auto-square-off" className="text-slate-300">Auto Square-off</Label>
                <Switch id="auto-square-off" />
              </div>
              
              <div className="flex items-center justify-between">
                <Label htmlFor="sound-alerts" className="text-slate-300">Sound Alerts</Label>
                <Switch id="sound-alerts" defaultChecked />
              </div>
            </CardContent>
          </Card>

          {/* Chart Settings */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <i className="fas fa-chart-bar mr-2 text-green-500"></i>
                Chart Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="default-timeframe" className="text-slate-300">Default Timeframe</Label>
                <select 
                  id="default-timeframe"
                  className="w-full p-2 bg-slate-700 border border-slate-600 rounded text-white"
                  defaultValue="5m"
                >
                  <option value="1m">1 Minute</option>
                  <option value="5m">5 Minutes</option>
                  <option value="15m">15 Minutes</option>
                  <option value="1h">1 Hour</option>
                  <option value="1d">1 Day</option>
                </select>
              </div>
              
              <div className="flex items-center justify-between">
                <Label htmlFor="show-volume" className="text-slate-300">Show Volume</Label>
                <Switch id="show-volume" defaultChecked />
              </div>
              
              <div className="flex items-center justify-between">
                <Label htmlFor="dark-theme" className="text-slate-300">Dark Theme</Label>
                <Switch id="dark-theme" defaultChecked />
              </div>
            </CardContent>
          </Card>

          {/* API Configuration */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <i className="fas fa-key mr-2 text-yellow-500"></i>
                API Configuration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="broker-api" className="text-slate-300">Broker API Key</Label>
                <Input
                  id="broker-api"
                  type="password"
                  placeholder="Enter your broker API key"
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              
              <div>
                <Label htmlFor="data-feed" className="text-slate-300">Data Feed URL</Label>
                <Input
                  id="data-feed"
                  type="url"
                  placeholder="https://api.example.com"
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                Test Connection
              </Button>
            </CardContent>
          </Card>

          {/* Account Info */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <i className="fas fa-user mr-2 text-purple-500"></i>
                Account Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="username" className="text-slate-300">Username</Label>
                <Input
                  id="username"
                  defaultValue="john.doe"
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              
              <div>
                <Label htmlFor="email" className="text-slate-300">Email</Label>
                <Input
                  id="email"
                  type="email"
                  defaultValue="john.doe@example.com"
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              
              <Button variant="outline" className="w-full bg-slate-700 border-slate-600">
                Change Password
              </Button>
            </CardContent>
          </Card>
        </div>
        
        <div className="mt-6 flex space-x-4">
          <Button className="bg-primary-600 hover:bg-primary-700">
            Save Settings
          </Button>
          <Button variant="outline" className="bg-slate-700 border-slate-600">
            Reset to Default
          </Button>
        </div>
      </div>
    </div>
  );
}