import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import TradingChart from "@/components/TradingChart";
import TopBar from "@/components/TopBar";
import MarketDepth from "@/components/MarketDepth";
import Watchlist from "@/components/Watchlist";
import PineScriptEditor from "@/components/PineScriptEditor";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useMarketData } from "@/hooks/useMarketData";

export default function TradingPage() {
  const [selectedSymbol, setSelectedSymbol] = useState("NIFTY25MAR25_18500_CE");
  const [showPineScript, setShowPineScript] = useState(false);
  const [timeframe, setTimeframe] = useState("1m");
  const [activeTab, setActiveTab] = useState("watchlist");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Initialize WebSocket connection for real-time data
  const { isConnected, subscribe, unsubscribe } = useWebSocket();
  const { marketData, orderBook } = useMarketData(selectedSymbol);

  // Subscribe to selected symbol for real-time updates
  useEffect(() => {
    if (isConnected) {
      subscribe([selectedSymbol]);
    }
    return () => {
      if (isConnected) {
        unsubscribe([selectedSymbol]);
      }
    };
  }, [selectedSymbol, isConnected, subscribe, unsubscribe]);

  const handleSymbolChange = (symbol: string) => {
    console.log(`handleSymbolChange called: ${selectedSymbol} -> ${symbol}`);
    if (symbol !== selectedSymbol) {
      console.log(`Setting new symbol: ${symbol}`);
      setSelectedSymbol(symbol);
      setMobileMenuOpen(false); // Close mobile menu when symbol is selected
    } else {
      console.log(`Symbol ${symbol} already selected`);
    }
  };

  const handleTimeframeChange = (tf: string) => {
    setTimeframe(tf);
  };

  const openPineScript = () => {
    console.log('Pine Script button clicked');
    setShowPineScript(true);
  };

  const closePineScript = () => {
    setShowPineScript(false);
  };

  return (
    <div className="h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex flex-col relative overflow-hidden">
      {/* Ambient Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 via-emerald-500/5 to-purple-500/5 animate-pulse"></div>
      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-0 left-0 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      
      {/* Top Navigation */}
      <TopBar 
        onSymbolSelect={handleSymbolChange}
        selectedSymbol={selectedSymbol}
        isConnected={isConnected}
      />
      
      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden relative z-10">
        {/* Chart Section */}
        <div className="flex-1 flex flex-col min-w-0 p-4 gap-4">
          {/* Chart Container - Enhanced */}
          <div className="flex-1 bg-slate-900/80 backdrop-blur-xl border border-slate-700/50 rounded-2xl shadow-2xl overflow-hidden relative group">
            {/* Chart Header */}
            <div className="h-12 bg-gradient-to-r from-slate-800/90 to-slate-700/90 backdrop-blur-sm border-b border-slate-600/50 flex items-center justify-between px-6">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 bg-emerald-400 rounded-full animate-pulse shadow-lg shadow-emerald-400/50"></div>
                <span className="text-emerald-400 font-semibold text-sm tracking-wider">LIVE CHART</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span className="bg-slate-700/50 px-2 py-1 rounded-md">{timeframe}</span>
                <span className="text-emerald-400">●</span>
                <span>{selectedSymbol.replace(/_/g, ' ')}</span>
              </div>
            </div>
            
            {/* Chart Content */}
            <div className="h-[calc(100%-3rem)] relative">
              <TradingChart 
                symbol={selectedSymbol}
                timeframe={timeframe}
                marketData={marketData}
              />
              
              {/* Chart Overlay Effects */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/20 to-transparent pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
          </div>
          
          {/* Market Depth - Enhanced */}
          <div className="h-48 bg-slate-900/80 backdrop-blur-xl border border-slate-700/50 rounded-2xl shadow-2xl overflow-hidden">
            {/* Market Depth Header */}
            <div className="h-10 bg-gradient-to-r from-slate-800/90 to-slate-700/90 backdrop-blur-sm border-b border-slate-600/50 flex items-center justify-between px-6">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse shadow-lg shadow-blue-400/50"></div>
                <span className="text-blue-400 font-semibold text-sm tracking-wider">ORDER BOOK</span>
              </div>
              <div className="text-xs text-slate-400">Level II</div>
            </div>
            
            {/* Market Depth Content */}
            <div className="h-[calc(100%-2.5rem)]">
              <MarketDepth 
                symbol={selectedSymbol}
                orderBook={orderBook}
                currentPrice={marketData?.ltp}
              />
            </div>
          </div>
        </div>

        {/* Side Panel - Enhanced */}
        <div className={`
          lg:w-80 flex-shrink-0 bg-slate-900/80 backdrop-blur-xl border-l border-slate-700/50 
          lg:flex flex-col lg:static absolute inset-y-0 right-0 z-40 transform transition-transform duration-300
          ${mobileMenuOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}
        `}>
          {/* Side Panel Header */}
          <div className="h-12 bg-gradient-to-r from-slate-800/90 to-slate-700/90 backdrop-blur-sm border-b border-slate-600/50 flex items-center justify-between px-6">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse shadow-lg shadow-purple-400/50"></div>
              <span className="text-purple-400 font-semibold text-sm tracking-wider">TRADING TOOLS</span>
            </div>
            <button 
              onClick={() => setMobileMenuOpen(false)}
              className="lg:hidden text-slate-400 hover:text-white p-1"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="bg-slate-800/50 border-b border-slate-700/50 flex">
            <button 
              onClick={() => setActiveTab('watchlist')}
              className={`flex-1 py-3 px-4 text-sm font-medium transition-colors relative ${
                activeTab === 'watchlist' 
                  ? 'text-emerald-400 bg-slate-700/50' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              ⭐ Watchlist
              {activeTab === 'watchlist' && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-400"></div>
              )}
            </button>
            <button 
              onClick={() => setActiveTab('orders')}
              className={`flex-1 py-3 px-4 text-sm font-medium transition-colors relative ${
                activeTab === 'orders' 
                  ? 'text-blue-400 bg-slate-700/50' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              📋 Orders
              {activeTab === 'orders' && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-400"></div>
              )}
            </button>
          </div>

          {/* Tab Content */}
          <div className="flex-1 overflow-hidden">
            {activeTab === 'watchlist' && (
              <Watchlist 
                onSymbolSelect={handleSymbolChange}
                selectedSymbol={selectedSymbol}
              />
            )}
            
            {activeTab === 'orders' && (
              <div className="p-4 h-full">
                <div className="text-center text-slate-400 mt-8">
                  <div className="text-2xl mb-4">📋</div>
                  <div className="text-lg font-semibold text-white mb-2">Order Book</div>
                  <div className="text-sm">Your open orders will appear here</div>
                  
                  {/* Quick Order Panel */}
                  <div className="mt-8 bg-slate-800/50 backdrop-blur-sm rounded-xl p-4 text-left border border-slate-600/30">
                    <div className="text-white font-semibold mb-4 flex items-center gap-2">
                      <div className="w-2 h-2 bg-orange-400 rounded-full"></div>
                      Quick Order
                    </div>
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-2">
                        <button className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white py-2 px-3 rounded-lg text-sm font-medium transition-all shadow-lg">
                          BUY
                        </button>
                        <button className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white py-2 px-3 rounded-lg text-sm font-medium transition-all shadow-lg">
                          SELL
                        </button>
                      </div>
                      <div className="text-xs text-slate-400 flex justify-between">
                        <span>Qty: <span className="text-white font-mono">50</span></span>
                        <span>Price: <span className="text-white font-mono">₹{marketData?.ltp || '245.5'}</span></span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Mobile Overlay */}
        {mobileMenuOpen && (
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden backdrop-blur-sm"
            onClick={() => setMobileMenuOpen(false)}
          />
        )}
      </div>

      {/* Pine Script Panel - Enhanced */}
      {showPineScript && (
        <div className="fixed bottom-0 left-0 right-0 h-80 sm:h-96 bg-slate-900/95 backdrop-blur-xl border-t border-slate-700/50 z-40 shadow-2xl">
          <PineScriptEditor 
            onClose={closePineScript}
            selectedSymbol={selectedSymbol}
          />
        </div>
      )}

      {/* Floating Action Buttons - Enhanced */}
      <div className="fixed bottom-24 sm:bottom-32 right-4 sm:right-6 flex flex-col gap-3 z-50">
        {/* Mobile Menu Button */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="lg:hidden bg-gradient-to-r from-slate-700 to-slate-600 hover:from-slate-600 hover:to-slate-500 text-white p-3 rounded-full shadow-2xl transition-all duration-200 group backdrop-blur-sm border border-slate-600/50"
          title="Toggle Tools Panel"
        >
          <svg className="w-5 h-5 transition-transform group-hover:scale-110" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v4" />
          </svg>
        </button>

        {/* Pine Script Button */}
        <button
          onClick={() => setShowPineScript(!showPineScript)}
          className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white p-3 sm:p-4 rounded-full shadow-2xl transition-all duration-200 group backdrop-blur-sm border border-emerald-400/20"
          title="Toggle Pine Script Editor"
        >
          <svg className="w-5 h-5 sm:w-6 sm:h-6 transition-transform group-hover:scale-110" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
          </svg>
          {showPineScript && (
            <span className="absolute -top-12 right-0 bg-slate-800/90 backdrop-blur-sm text-white text-xs px-2 py-1 rounded-md whitespace-nowrap hidden sm:block border border-slate-600/50">
              Close Pine Script
            </span>
          )}
        </button>
      </div>
    </div>
  );
}