import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import TradingChart from "@/components/TradingChart";
import TopBar from "@/components/TopBar";
import MarketDepth from "@/components/MarketDepth";
import Watchlist from "@/components/Watchlist";
import PineScriptEditor from "@/components/PineScriptEditor";
import OrderPanel from "@/components/OrderPanel";

import { useWebSocket } from "@/hooks/useWebSocket";
import { useMarketData } from "@/hooks/useMarketData";

export default function TradingPage() {
  const [selectedSymbol, setSelectedSymbol] = useState("NIFTY25MAR25_18500_CE");
  const [showPineScript, setShowPineScript] = useState(false);
  const [timeframe, setTimeframe] = useState("1m");


  // Initialize WebSocket connection for real-time data
  const { isConnected, subscribe, unsubscribe } = useWebSocket();
  const { marketData, orderBook } = useMarketData(selectedSymbol);

  // Subscribe to selected symbol for real-time updates
  useEffect(() => {
    if (isConnected) {
      subscribe([selectedSymbol]);
    }
    return () => {
      if (isConnected) {
        unsubscribe([selectedSymbol]);
      }
    };
  }, [selectedSymbol, isConnected, subscribe, unsubscribe]);

  const handleSymbolChange = (symbol: string) => {
    console.log(`handleSymbolChange called: ${selectedSymbol} -> ${symbol}`);
    if (symbol !== selectedSymbol) {
      console.log(`Setting new symbol: ${symbol}`);
      setSelectedSymbol(symbol);

    } else {
      console.log(`Symbol ${symbol} already selected`);
    }
  };

  const handleTimeframeChange = (tf: string) => {
    setTimeframe(tf);
  };

  const openPineScript = () => {
    console.log('Pine Script button clicked');
    setShowPineScript(true);
  };

  const closePineScript = () => {
    setShowPineScript(false);
  };

  return (
    <div className="flex-1 flex flex-col h-full">
      {/* Professional Header */}
      <div className="h-16 bg-gradient-to-r from-slate-900 to-slate-800 border-b border-slate-700 flex items-center justify-between px-6 relative">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">TM</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">TradeMaster Pro</h1>
              <p className="text-xs text-slate-400">Professional F&O Trading Platform</p>
            </div>
          </div>
          
          <div className="h-8 w-px bg-slate-600"></div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-400' : 'bg-red-400'}`}></div>
              <span className="text-sm text-slate-300">{isConnected ? 'Connected' : 'Disconnected'}</span>
            </div>
            
            <div className="bg-slate-800 px-3 py-1 rounded-md border border-slate-600">
              <span className="text-xs text-slate-400">Symbol: </span>
              <span className="text-sm text-white font-mono">{selectedSymbol.replace(/_/g, ' ')}</span>
            </div>
            
            {marketData && (
              <div className="flex items-center gap-3">
                <div className="bg-slate-800 px-3 py-1 rounded-md border border-slate-600">
                  <span className="text-xs text-slate-400">LTP: </span>
                  <span className="text-sm text-white font-mono">₹{marketData.ltp}</span>
                </div>
                <div className={`px-3 py-1 rounded-md border ${marketData.change >= 0 ? 'bg-emerald-900/30 border-emerald-600 text-emerald-400' : 'bg-red-900/30 border-red-600 text-red-400'}`}>
                  <span className="text-sm font-mono">{marketData.change >= 0 ? '+' : ''}₹{marketData.change}</span>
                </div>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="text-xs text-slate-400">
            {new Date().toLocaleTimeString()}
          </div>
          <div className="bg-slate-800 px-2 py-1 rounded border border-slate-600">
            <span className="text-xs text-emerald-400 font-mono">NSE</span>
          </div>
        </div>
      </div>
      
      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Chart Section */}
        <div className="flex-1 flex flex-col bg-slate-900 min-w-0">
          {/* Professional Chart Controls */}
          <div className="h-14 bg-slate-800 border-b border-slate-700 flex items-center justify-between px-6">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-3">
                <h2 className="text-lg font-semibold text-white">Chart Analysis</h2>
                <span className={`px-2 py-1 rounded text-xs font-medium ${selectedSymbol.includes('CE') ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'}`}>
                  {selectedSymbol.includes('CE') ? 'CALL OPTION' : 'PUT OPTION'}
                </span>
              </div>
              
              <div className="h-6 w-px bg-slate-600"></div>
              
              <div className="flex items-center gap-4">
                <div className="text-sm text-slate-400">Timeframe:</div>
                <div className="flex bg-slate-700/50 rounded-lg border border-slate-600">
                  {['1m', '5m', '15m', '1h', '1d'].map((tf) => (
                    <button
                      key={tf}
                      onClick={() => handleTimeframeChange(tf)}
                      className={`px-4 py-2 text-sm font-medium transition-all duration-200 first:rounded-l-lg last:rounded-r-lg ${
                        timeframe === tf
                          ? 'bg-emerald-600 text-white shadow-lg'
                          : 'text-slate-300 hover:text-white hover:bg-slate-600'
                      }`}
                    >
                      {tf}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Button 
                variant="outline" 
                size="sm"
                className="bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600 hover:text-white"
              >
                Technical Indicators
              </Button>

              <Button 
                variant="outline" 
                size="sm"
                onClick={openPineScript}
                className="bg-emerald-700 border-emerald-600 text-emerald-100 hover:bg-emerald-600 hover:text-white"
              >
                Pine Script Editor
              </Button>
            </div>
          </div>

          {/* Chart Container */}
          <div className="flex-1 bg-slate-900 relative overflow-hidden">
            <TradingChart 
              key={selectedSymbol} // Force re-render when symbol changes
              symbol={selectedSymbol}
              timeframe={timeframe}
              marketData={marketData}
            />
          </div>
          
          {/* Professional Market Depth Section */}
          <div className="h-72 bg-slate-800 border-t border-slate-700 flex flex-col">
            <div className="h-12 bg-slate-900 border-b border-slate-600 flex items-center justify-between px-6">
              <div className="flex items-center gap-3">
                <h3 className="text-white font-semibold">Order Book</h3>
                <span className="bg-blue-600 text-white px-2 py-1 rounded text-xs font-medium">Level II</span>
              </div>
              <div className="flex items-center gap-4 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-emerald-400 rounded-full"></div>
                  <span>Bid</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                  <span>Ask</span>
                </div>
                <span>Real-time Depth</span>
              </div>
            </div>
            <div className="flex-1 overflow-hidden">
              <MarketDepth 
                symbol={selectedSymbol}
                orderBook={orderBook}
                currentPrice={marketData?.ltp}
              />
            </div>
          </div>
        </div>
        
        {/* Order Panel */}
        <OrderPanel 
          symbol={selectedSymbol}
          marketData={marketData}
          isConnected={isConnected}
        />
      </div>

      {/* Professional Pine Script Panel */}
      {showPineScript && (
        <div className="fixed bottom-0 left-0 right-0 h-80 sm:h-96 bg-slate-900 border-t border-slate-700 z-40 shadow-2xl">
          <div className="h-12 bg-slate-800 border-b border-slate-600 flex items-center justify-between px-6">
            <div className="flex items-center gap-3">
              <svg className="w-5 h-5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
              </svg>
              <h3 className="text-white font-semibold">Pine Script Editor</h3>
              <span className="bg-emerald-600 text-white px-2 py-1 rounded text-xs">v5</span>
            </div>
            <button
              onClick={closePineScript}
              className="text-slate-400 hover:text-white p-2 rounded bg-slate-700 hover:bg-slate-600 transition-colors"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          <div className="h-[calc(100%-3rem)]">
            <PineScriptEditor 
              onClose={closePineScript}
              selectedSymbol={selectedSymbol}
            />
          </div>
        </div>
      )}
    </div>
  );
}