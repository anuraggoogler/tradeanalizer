import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { TrendingUp, Activity, BarChart3, AlertTriangle, Settings, LogOut } from "lucide-react";

export default function Home() {
  const { user } = useAuth();

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 text-slate-100 overflow-auto">
      <div className="p-6">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">
            Welcome back, {user?.firstName || 'Trader'}!
          </h2>
          <p className="text-slate-400">
            Your professional F&O trading dashboard is ready.
          </p>
        </div>

        {/* Dashboard Overview */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400">Account Balance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">₹1,00,000</div>
              <p className="text-xs text-green-400 mt-1">+2.5% today</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400">Day P&L</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-400">+₹2,500</div>
              <p className="text-xs text-slate-400 mt-1">5 positions</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400">Margin Used</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-400">₹25,000</div>
              <p className="text-xs text-slate-400 mt-1">25% utilized</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400">Active Strategies</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-400">3</div>
              <p className="text-xs text-slate-400 mt-1">2 profitable</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-900 to-blue-800 border-blue-700 cursor-pointer hover:from-blue-800 hover:to-blue-700 transition-all">
            <CardHeader>
              <BarChart3 className="h-8 w-8 text-blue-300 mb-2" />
              <CardTitle className="text-white">Trading Terminal</CardTitle>
              <CardDescription className="text-blue-200">
                Access real-time charts and place orders
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-gradient-to-br from-green-900 to-green-800 border-green-700 cursor-pointer hover:from-green-800 hover:to-green-700 transition-all">
            <CardHeader>
              <Activity className="h-8 w-8 text-green-300 mb-2" />
              <CardTitle className="text-white">Pine Script Lab</CardTitle>
              <CardDescription className="text-green-200">
                Develop and backtest trading strategies
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-gradient-to-br from-purple-900 to-purple-800 border-purple-700 cursor-pointer hover:from-purple-800 hover:to-purple-700 transition-all">
            <CardHeader>
              <AlertTriangle className="h-8 w-8 text-purple-300 mb-2" />
              <CardTitle className="text-white">Risk Manager</CardTitle>
              <CardDescription className="text-purple-200">
                Monitor positions and manage risk
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* Recent Activity */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Recent Trades</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">NIFTY 18500 CE</p>
                    <p className="text-sm text-slate-400">BUY • 10:30 AM</p>
                  </div>
                  <Badge variant="outline" className="text-green-400 border-green-400">
                    +₹850
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">BANKNIFTY 40000 PE</p>
                    <p className="text-sm text-slate-400">SELL • 9:45 AM</p>
                  </div>
                  <Badge variant="outline" className="text-red-400 border-red-400">
                    -₹320
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">RELIANCE 2500 CE</p>
                    <p className="text-sm text-slate-400">BUY • 9:15 AM</p>
                  </div>
                  <Badge variant="outline" className="text-green-400 border-green-400">
                    +₹1,200
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Active Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">NIFTY above 18600</p>
                    <p className="text-sm text-slate-400">Price Alert</p>
                  </div>
                  <Badge variant="outline" className="text-yellow-400 border-yellow-400">
                    Active
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">RSI Oversold Signal</p>
                    <p className="text-sm text-slate-400">Technical Alert</p>
                  </div>
                  <Badge variant="outline" className="text-blue-400 border-blue-400">
                    Monitoring
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Volume Spike Alert</p>
                    <p className="text-sm text-slate-400">Market Alert</p>
                  </div>
                  <Badge variant="outline" className="text-green-400 border-green-400">
                    Triggered
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}