import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, BarChart3, Activity, Shield, Zap, Users } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-900/80 backdrop-blur-md">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <TrendingUp className="h-8 w-8 text-blue-400" />
            <h1 className="text-2xl font-bold text-white">TradeMaster Pro</h1>
          </div>
          <Button 
            onClick={() => window.location.href = '/api/login'}
            className="bg-blue-600 hover:bg-blue-700"
          >
            Get Started
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-5xl font-bold text-white mb-6">
            Professional F&O Trading Platform
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Advanced algorithmic trading with real-time market data, Pine Script strategies, 
            and comprehensive risk management tools for Indian F&O markets.
          </p>
          <Button 
            size="lg"
            onClick={() => window.location.href = '/api/login'}
            className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-3"
          >
            Start Trading Now
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16">
        <h3 className="text-3xl font-bold text-white text-center mb-12">
          Professional Trading Features
        </h3>
        <div className="grid md:grid-cols-3 gap-8">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <BarChart3 className="h-12 w-12 text-blue-400 mb-4" />
              <CardTitle className="text-white">TradingView Integration</CardTitle>
              <CardDescription className="text-gray-300">
                Professional charting with real-time F&O data and advanced technical analysis tools.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <Activity className="h-12 w-12 text-green-400 mb-4" />
              <CardTitle className="text-white">Pine Script Engine</CardTitle>
              <CardDescription className="text-gray-300">
                Custom strategy development with backtesting and automated signal generation.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <Shield className="h-12 w-12 text-purple-400 mb-4" />
              <CardTitle className="text-white">Risk Management</CardTitle>
              <CardDescription className="text-gray-300">
                Advanced portfolio analytics, position sizing, and automated risk controls.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <Zap className="h-12 w-12 text-yellow-400 mb-4" />
              <CardTitle className="text-white">Real-time Alerts</CardTitle>
              <CardDescription className="text-gray-300">
                Price and volume alerts with custom conditions and instant notifications.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <Users className="h-12 w-12 text-red-400 mb-4" />
              <CardTitle className="text-white">Strategy Library</CardTitle>
              <CardDescription className="text-gray-300">
                Access community strategies and share your own trading algorithms.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <TrendingUp className="h-12 w-12 text-cyan-400 mb-4" />
              <CardTitle className="text-white">Performance Analytics</CardTitle>
              <CardDescription className="text-gray-300">
                Detailed P&L tracking, drawdown analysis, and performance metrics.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-16 text-center">
        <div className="bg-gray-800 rounded-2xl p-12 border border-gray-700">
          <h3 className="text-3xl font-bold text-white mb-4">
            Ready to Transform Your Trading?
          </h3>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Join thousands of traders using TradeMaster Pro for professional algorithmic trading 
            in Indian F&O markets.
          </p>
          <Button 
            size="lg"
            onClick={() => window.location.href = '/api/login'}
            className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-3"
          >
            Get Started Today
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-800 bg-gray-900 py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-gray-400">
            © 2025 TradeMaster Pro. Professional algorithmic trading platform.
          </p>
        </div>
      </footer>
    </div>
  );
}