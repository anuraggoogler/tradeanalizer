import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";

export default function RiskToolsPage() {
  const [optionPrice, setOptionPrice] = useState(250);
  const [quantity, setQuantity] = useState(25);
  const [strikePrice, setStrikePrice] = useState(18500);

  const maxLoss = optionPrice * quantity;
  const maxGain = (strikePrice - optionPrice) * quantity;
  const breakeven = strikePrice + optionPrice;

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 text-slate-100 overflow-auto">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-white mb-6">Risk Management Tools</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Position Calculator */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <i className="fas fa-calculator mr-2 text-blue-500"></i>
                Position Size Calculator
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="option-price" className="text-slate-300">Option Price (₹)</Label>
                <Input
                  id="option-price"
                  type="number"
                  value={optionPrice}
                  onChange={(e) => setOptionPrice(Number(e.target.value))}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              <div>
                <Label htmlFor="quantity" className="text-slate-300">Quantity (Lots)</Label>
                <Input
                  id="quantity"
                  type="number"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              <div>
                <Label htmlFor="strike-price" className="text-slate-300">Strike Price (₹)</Label>
                <Input
                  id="strike-price"
                  type="number"
                  value={strikePrice}
                  onChange={(e) => setStrikePrice(Number(e.target.value))}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              
              <div className="pt-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Max Loss:</span>
                  <span className="text-red-400 font-mono">₹{maxLoss.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Max Gain:</span>
                  <span className="text-green-400 font-mono">₹{maxGain.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Breakeven:</span>
                  <span className="text-white font-mono">₹{breakeven}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Risk Metrics */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <i className="fas fa-shield-alt mr-2 text-green-500"></i>
                Risk Metrics
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-700 p-3 rounded">
                  <div className="text-xs text-slate-400 uppercase">Greeks</div>
                  <div className="space-y-1 mt-2">
                    <div className="flex justify-between text-sm">
                      <span>Delta:</span>
                      <span className="font-mono">0.65</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Gamma:</span>
                      <span className="font-mono">0.02</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Theta:</span>
                      <span className="font-mono text-red-400">-0.15</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Vega:</span>
                      <span className="font-mono">0.08</span>
                    </div>
                  </div>
                </div>
                
                <div className="bg-slate-700 p-3 rounded">
                  <div className="text-xs text-slate-400 uppercase">Portfolio</div>
                  <div className="space-y-1 mt-2">
                    <div className="flex justify-between text-sm">
                      <span>Total P&L:</span>
                      <span className="font-mono text-green-400">+₹12,450</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Day P&L:</span>
                      <span className="font-mono text-green-400">+₹2,340</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Margin Used:</span>
                      <span className="font-mono">₹45,000</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Available:</span>
                      <span className="font-mono">₹85,650</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <Button className="w-full bg-primary-600 hover:bg-primary-700">
                <i className="fas fa-download mr-2"></i>
                Export Risk Report
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}