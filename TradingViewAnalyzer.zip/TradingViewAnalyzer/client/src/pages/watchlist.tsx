import Watchlist from "@/components/Watchlist";
import { useState } from "react";

export default function WatchlistPage() {
  const [selectedSymbol, setSelectedSymbol] = useState("NIFTY25MAR25_18500_CE");

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 text-slate-100">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-white mb-6">Watchlist Management</h1>
        <div className="bg-slate-800 rounded-lg border border-slate-700">
          <Watchlist 
            onSymbolSelect={setSelectedSymbol}
            selectedSymbol={selectedSymbol}
          />
        </div>
      </div>
    </div>
  );
}