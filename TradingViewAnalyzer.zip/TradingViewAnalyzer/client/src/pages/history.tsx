import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function HistoryPage() {
  const trades = [
    {
      id: 1,
      symbol: "NIFTY25MAR25_18500_CE",
      action: "BUY",
      quantity: 25,
      price: 245.50,
      time: "10:30 AM",
      date: "Today",
      pnl: +1250.75,
      status: "Executed"
    },
    {
      id: 2,
      symbol: "BANKNIFTY25MAR25_45000_PE",
      action: "SELL",
      quantity: 15,
      price: 380.25,
      time: "11:45 AM",
      date: "Today",
      pnl: -750.50,
      status: "Executed"
    },
    {
      id: 3,
      symbol: "NIFTY25MAR25_18400_CE",
      action: "BUY",
      quantity: 50,
      price: 195.75,
      time: "02:15 PM",
      date: "Yesterday",
      pnl: +2340.25,
      status: "Executed"
    }
  ];

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 text-slate-100 overflow-auto">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-white mb-6">Trading History</h1>
        
        <div className="space-y-4">
          {trades.map((trade) => (
            <Card key={trade.id} className="bg-slate-800 border-slate-700">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${
                      trade.action === "BUY" ? "bg-green-600" : "bg-red-600"
                    }`}>
                      {trade.action === "BUY" ? "B" : "S"}
                    </div>
                    <div>
                      <h3 className="font-semibold text-white">{trade.symbol}</h3>
                      <p className="text-sm text-slate-400">
                        {trade.action} {trade.quantity} @ ₹{trade.price}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-6">
                    <div className="text-right">
                      <div className="text-sm text-slate-400">{trade.date}</div>
                      <div className="text-sm text-slate-300">{trade.time}</div>
                    </div>
                    
                    <div className="text-right">
                      <div className={`font-mono font-bold ${
                        trade.pnl >= 0 ? "text-green-400" : "text-red-400"
                      }`}>
                        {trade.pnl >= 0 ? "+" : ""}₹{Math.abs(trade.pnl).toLocaleString()}
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {trade.status}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white text-sm">Today's Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Total Trades:</span>
                  <span className="text-white">2</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Net P&L:</span>
                  <span className="text-green-400 font-mono">+₹500.25</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white text-sm">This Week</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Total Trades:</span>
                  <span className="text-white">12</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Net P&L:</span>
                  <span className="text-green-400 font-mono">+₹8,450.75</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white text-sm">This Month</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Total Trades:</span>
                  <span className="text-white">45</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Net P&L:</span>
                  <span className="text-green-400 font-mono">+₹25,340.50</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}