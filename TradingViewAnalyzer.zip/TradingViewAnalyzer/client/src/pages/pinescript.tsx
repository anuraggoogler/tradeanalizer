import PineScriptEditor from "@/components/PineScriptEditor";
import { useState } from "react";

export default function PineScriptPage() {
  const [selectedSymbol] = useState("NIFTY25MAR25_18500_CE");

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950">
      <PineScriptEditor 
        onClose={() => window.history.back()}
        selectedSymbol={selectedSymbol}
      />
    </div>
  );
}