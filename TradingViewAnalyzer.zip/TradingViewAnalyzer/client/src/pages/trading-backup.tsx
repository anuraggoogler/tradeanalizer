import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import TradingChart from "@/components/TradingChart";
import TopBar from "@/components/TopBar";
import MarketDepth from "@/components/MarketDepth";
import Watchlist from "@/components/Watchlist";
import PineScriptEditor from "@/components/PineScriptEditor";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useMarketData } from "@/hooks/useMarketData";

export default function TradingPage() {
  const [selectedSymbol, setSelectedSymbol] = useState("NIFTY25MAR25_18500_CE");
  const [showPineScript, setShowPineScript] = useState(false);
  const [timeframe, setTimeframe] = useState("1m");
  const [activeTab, setActiveTab] = useState("watchlist");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Initialize WebSocket connection for real-time data
  const { isConnected, subscribe, unsubscribe } = useWebSocket();
  const { marketData, orderBook } = useMarketData(selectedSymbol);

  // Subscribe to selected symbol for real-time updates
  useEffect(() => {
    if (isConnected) {
      subscribe([selectedSymbol]);
    }
    return () => {
      if (isConnected) {
        unsubscribe([selectedSymbol]);
      }
    };
  }, [selectedSymbol, isConnected, subscribe, unsubscribe]);

  const handleSymbolChange = (symbol: string) => {
    console.log(`handleSymbolChange called: ${selectedSymbol} -> ${symbol}`);
    if (symbol !== selectedSymbol) {
      console.log(`Setting new symbol: ${symbol}`);
      setSelectedSymbol(symbol);
      setMobileMenuOpen(false); // Close mobile menu when symbol is selected
    } else {
      console.log(`Symbol ${symbol} already selected`);
    }
  };

  const handleTimeframeChange = (tf: string) => {
    setTimeframe(tf);
  };

  const openPineScript = () => {
    console.log('Pine Script button clicked');
    setShowPineScript(true);
  };

  const closePineScript = () => {
    setShowPineScript(false);
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden h-full">
      <TopBar 
        onSymbolSelect={handleSymbolChange}
        selectedSymbol={selectedSymbol}
        isConnected={isConnected}
      />
      <div className="flex flex-1 overflow-hidden relative">
        {/* Chart Area - Responsive Layout */}
        <div className="flex-1 flex flex-col bg-slate-900 min-w-0 order-2 lg:order-1">
          {/* Chart Toolbar - Responsive */}
          <div className="bg-slate-800 border-b border-slate-700 px-2 sm:px-4 py-2 sm:py-3">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
                {/* Symbol Info - Clickable */}
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={() => setMobileMenuOpen(true)}
                    className="text-sm sm:text-lg font-bold text-white truncate hover:text-emerald-400 transition-colors lg:cursor-default lg:hover:text-white"
                  >
                    {selectedSymbol.replace('_', ' ').replace('_', ' ')}
                  </button>
                  <span className="text-xs bg-blue-500 text-white px-2 py-1 rounded flex-shrink-0">
                    {selectedSymbol.includes('CE') ? 'CALL' : 'PUT'}
                  </span>
                </div>
                
                {/* Price Display */}
                {marketData && (
                  <div className="flex items-center gap-2 sm:gap-4 text-xs sm:text-sm overflow-x-auto">
                    <div className="flex-shrink-0">
                      <span className="text-slate-400">LTP:</span>
                      <span className="font-mono text-white ml-1">₹{marketData.ltp}</span>
                    </div>
                    <div className={`flex-shrink-0 ${marketData.change >= 0 ? "text-green-400" : "text-red-400"}`}>
                      <span>{marketData.change >= 0 ? '+' : ''}₹{marketData.change}</span>
                      <span className="ml-1">({marketData.changePercent}%)</span>
                    </div>
                    <div className="flex-shrink-0 hidden sm:block">
                      <span className="text-slate-400">Vol:</span>
                      <span className="font-mono text-white ml-1">{marketData.volume?.toLocaleString()}</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Chart Controls */}
              <div className="flex items-center justify-between sm:justify-end gap-3">
                {/* Timeframe Selector */}
                <div className="flex bg-slate-700 rounded-lg p-1 text-xs">
                  {['1m', '5m', '15m', '1h', '1d'].map((tf) => (
                    <button
                      key={tf}
                      onClick={() => handleTimeframeChange(tf)}
                      className={`px-2 sm:px-3 py-1 font-medium rounded transition-colors ${
                        timeframe === tf
                          ? 'bg-emerald-600 text-white'
                          : 'text-slate-300 hover:text-white'
                      }`}
                    >
                      {tf}
                    </button>
                  ))}
                </div>

                <Button 
                  variant="outline" 
                  size="sm"
                  className="bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600 hover:text-white hidden sm:flex"
                >
                  <i className="fas fa-plus mr-1"></i>
                  Indicators
                </Button>

                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={openPineScript}
                  className="bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600 hover:text-white hidden sm:flex"
                >
                  <i className="fas fa-code mr-1"></i>
                  Pine Script
                </Button>
              </div>
            </div>
          </div>

          {/* Chart Container */}
          <div className="flex-1 bg-slate-900 relative overflow-hidden">
            <TradingChart 
              key={selectedSymbol} // Force re-render when symbol changes
              symbol={selectedSymbol}
              timeframe={timeframe}
              marketData={marketData}
            />
          </div>
          
          {/* Market Depth Section - Below Chart */}
          <div className="h-80 lg:h-64 bg-slate-800 border-t border-slate-700 flex flex-col">
            <div className="bg-slate-900 border-b border-slate-600 px-4 py-2">
              <h3 className="text-white font-semibold text-sm">Market Depth</h3>
            </div>
            <div className="flex-1 overflow-hidden">
              <MarketDepth 
                symbol={selectedSymbol}
                orderBook={orderBook}
                currentPrice={marketData?.ltp}
              />
            </div>
          </div>
        </div>

        {/* Right Panel - Responsive with Mobile Drawer */}
        <div className={`
          ${mobileMenuOpen ? 'translate-x-0' : 'translate-x-full'} 
          lg:translate-x-0 
          fixed lg:relative 
          right-0 top-0 
          w-full sm:w-80 lg:w-80 
          h-full lg:h-auto 
          bg-slate-800 
          border-l border-slate-700 
          flex flex-col 
          z-40 lg:z-auto
          transition-transform duration-300 ease-in-out
          order-1 lg:order-2
        `}>
          {/* Mobile Close Button */}
          <div className="lg:hidden flex items-center justify-between p-4 border-b border-slate-700">
            <span className="text-white font-semibold">Trading Tools</span>
            <button
              onClick={() => setMobileMenuOpen(false)}
              className="text-slate-400 hover:text-white"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          {/* Tab Navigation */}
          <div className="flex bg-slate-900 border-b border-slate-600">
            <button
              onClick={() => setActiveTab('watchlist')}
              className={`flex-1 px-2 sm:px-4 py-3 text-xs sm:text-sm font-medium transition-colors ${
                activeTab === 'watchlist'
                  ? 'bg-slate-700 text-white border-b-2 border-emerald-500'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              Watchlist
            </button>
            <button
              onClick={() => setActiveTab('orders')}
              className={`flex-1 px-2 sm:px-4 py-3 text-xs sm:text-sm font-medium transition-colors ${
                activeTab === 'orders'
                  ? 'bg-slate-700 text-white border-b-2 border-emerald-500'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              Orders
            </button>
          </div>

          {/* Tab Content */}
          <div className="flex-1 overflow-hidden">
            {activeTab === 'watchlist' && (
              <Watchlist 
                onSymbolSelect={handleSymbolChange}
                selectedSymbol={selectedSymbol}
              />
            )}
            
            {activeTab === 'orders' && (
              <div className="p-4 h-full">
                <div className="text-center text-slate-400 mt-4 sm:mt-8">
                  <div className="text-2xl mb-4">📋</div>
                  <div className="text-lg font-semibold text-white mb-2">Order Book</div>
                  <div className="text-sm">Your open orders will appear here</div>
                  
                  {/* Quick Order Panel */}
                  <div className="mt-6 sm:mt-8 bg-slate-900 rounded-lg p-4 text-left">
                    <div className="text-white font-semibold mb-4">Quick Order</div>
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-2">
                        <button className="bg-green-600 hover:bg-green-700 text-white py-2 px-3 rounded text-sm font-medium transition-colors">
                          BUY
                        </button>
                        <button className="bg-red-600 hover:bg-red-700 text-white py-2 px-3 rounded text-sm font-medium transition-colors">
                          SELL
                        </button>
                      </div>
                      <div className="text-xs text-slate-400">
                        Qty: <span className="text-white font-mono">50</span> | 
                        Price: <span className="text-white font-mono">₹{marketData?.ltp || '245.5'}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Mobile Overlay */}
        {mobileMenuOpen && (
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden"
            onClick={() => setMobileMenuOpen(false)}
          />
        )}
      </div>

      {/* Pine Script Panel - Responsive */}
      {showPineScript && (
        <div className="fixed bottom-0 left-0 right-0 h-80 sm:h-96 bg-slate-800 border-t border-slate-700 z-40 shadow-2xl">
          <PineScriptEditor 
            onClose={closePineScript}
            selectedSymbol={selectedSymbol}
          />
        </div>
      )}

      {/* Floating Action Buttons */}
      <div className="fixed bottom-24 sm:bottom-32 right-4 sm:right-6 flex flex-col gap-3 z-50">
        {/* Mobile Menu Button */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="lg:hidden bg-slate-700 hover:bg-slate-600 text-white p-3 rounded-full shadow-2xl transition-all duration-200 group"
          title="Toggle Tools Panel"
        >
          <svg className="w-5 h-5 transition-transform group-hover:scale-110" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v4" />
          </svg>
        </button>

        {/* Pine Script Button */}
        <button
          onClick={() => setShowPineScript(!showPineScript)}
          className="bg-emerald-500 hover:bg-emerald-600 text-white p-3 sm:p-4 rounded-full shadow-2xl transition-all duration-200 group"
          title="Toggle Pine Script Editor"
        >
          <svg className="w-5 h-5 sm:w-6 sm:h-6 transition-transform group-hover:scale-110" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
          </svg>
          {showPineScript && (
            <span className="absolute -top-12 right-0 bg-slate-800 text-white text-xs px-2 py-1 rounded whitespace-nowrap hidden sm:block">
              Close Pine Script
            </span>
          )}
        </button>
      </div>
    </div>
  );
}