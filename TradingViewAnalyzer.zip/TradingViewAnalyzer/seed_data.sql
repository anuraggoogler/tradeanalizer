-- Insert sample F&O symbols
INSERT INTO symbols (symbol, name, type, underlying_asset, strike_price, expiry_date, lot_size, is_active) VALUES
('NIFTY25MAR25_18500_CE', 'NIFTY 25 MAR 25 18500 CE', 'CALL', 'NIFTY', '18500.00', '2025-03-27', 50, true),
('NIFTY25MAR25_18500_PE', 'NIFTY 25 MAR 25 18500 PE', 'PUT', 'NIFTY', '18500.00', '2025-03-27', 50, true),
('BANKNIFTY25MAR25_40000_CE', 'BANKNIFTY 25 MAR 25 40000 CE', 'CALL', 'BANKNIFTY', '40000.00', '2025-03-27', 25, true),
('BANKNIFTY25MAR25_40000_PE', 'BANKNIFTY 25 MAR 25 40000 PE', 'PUT', 'BANKNIFTY', '40000.00', '2025-03-27', 25, true),
('RELIANCE25MAR25_2500_CE', 'RELIANCE 25 MAR 25 2500 CE', 'CALL', 'RELIANCE', '2500.00', '2025-03-27', 250, true);

-- Insert demo user
INSERT INTO users (id, email, first_name, last_name, username, account_balance, trading_experience, risk_tolerance) VALUES
('demo', 'demo@trademaster.pro', 'Demo', 'Trader', 'demo_trader', '100000.00', 'intermediate', 'medium');

-- Insert sample Pine Scripts
INSERT INTO pine_scripts (user_id, name, description, code, category, tags, is_public) VALUES
('demo', 'RSI Mean Reversion', 'Strategy based on RSI oversold/overbought levels', 
'//@version=5
strategy("RSI Mean Reversion", overlay=false)

// Input parameters
rsi_length = input.int(14, "RSI Length")
rsi_overbought = input.int(70, "RSI Overbought")
rsi_oversold = input.int(30, "RSI Oversold")

// Calculate RSI
rsi = ta.rsi(close, rsi_length)

// Entry conditions
long_condition = rsi < rsi_oversold
short_condition = rsi > rsi_overbought

// Execute trades
if (long_condition)
    strategy.entry("Long", strategy.long)
if (short_condition)
    strategy.entry("Short", strategy.short)

// Plot RSI
plot(rsi, "RSI", color=color.blue)
hline(rsi_overbought, "Overbought", color=color.red)
hline(rsi_oversold, "Oversold", color=color.green)', 
'momentum', ARRAY['RSI', 'mean reversion', 'oscillator'], true),

('demo', 'Moving Average Crossover', 'Simple EMA crossover strategy for trend following',
'//@version=5
strategy("EMA Crossover", overlay=true)

// Input parameters
fast_length = input.int(9, "Fast EMA")
slow_length = input.int(21, "Slow EMA")

// Calculate EMAs
fast_ema = ta.ema(close, fast_length)
slow_ema = ta.ema(close, slow_length)

// Entry conditions
long_condition = ta.crossover(fast_ema, slow_ema)
short_condition = ta.crossunder(fast_ema, slow_ema)

// Execute trades
if (long_condition)
    strategy.entry("Long", strategy.long)
if (short_condition)
    strategy.entry("Short", strategy.short)

// Plot EMAs
plot(fast_ema, "Fast EMA", color=color.blue)
plot(slow_ema, "Slow EMA", color=color.red)', 
'trend', ARRAY['EMA', 'crossover', 'trend following'], true);

-- Insert sample alerts
INSERT INTO alerts (user_id, symbol_id, alert_type, condition, target_price, message, is_active) VALUES
('demo', 1, 'price', 'NIFTY > 18600', '18600.00', 'NIFTY above resistance level', true),
('demo', 3, 'price', 'BANKNIFTY < 39500', '39500.00', 'BANKNIFTY near support', true);

-- Insert sample watchlist items
INSERT INTO watchlists (user_id, symbol_id) VALUES
('demo', 1),
('demo', 2),
('demo', 3);
