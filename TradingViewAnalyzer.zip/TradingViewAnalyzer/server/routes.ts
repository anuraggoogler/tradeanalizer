import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { marketDataService } from "./services/marketData";
import { pineScriptService } from "./services/pineScript";
import { insertWatchlistSchema, insertPineScriptSchema, insertAlertSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware setup
  await setupAuth(app);

  const httpServer = createServer(app);

  // WebSocket server for real-time market data
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  const clients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    clients.add(ws);
    
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        if (data.type === 'subscribe') {
          // Handle subscription to symbols
          marketDataService.subscribe(data.symbols, ws);
        } else if (data.type === 'unsubscribe') {
          // Handle unsubscription
          marketDataService.unsubscribe(data.symbols, ws);
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      clients.delete(ws);
      marketDataService.unsubscribeAll(ws);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(ws);
    });
  });

  // Start market data service
  marketDataService.startRealtimeData((data) => {
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({
          type: 'marketData',
          data
        }));
      }
    });
  });

  // API Routes

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Symbols
  app.get('/api/symbols', async (req, res) => {
    try {
      const symbols = await storage.getActiveSymbols();
      res.json(symbols);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch symbols' });
    }
  });

  app.get('/api/symbols/search', async (req, res) => {
    try {
      const { q } = req.query;
      if (!q || typeof q !== 'string') {
        return res.status(400).json({ error: 'Query parameter required' });
      }
      
      const allSymbols = await storage.getActiveSymbols();
      const filtered = allSymbols.filter(symbol => 
        symbol.name.toLowerCase().includes(q.toLowerCase()) ||
        symbol.symbol.toLowerCase().includes(q.toLowerCase())
      );
      
      res.json(filtered);
    } catch (error) {
      res.status(500).json({ error: 'Failed to search symbols' });
    }
  });

  // Market Data
  app.get('/api/marketdata/:symbolId/latest', async (req, res) => {
    try {
      const symbolId = parseInt(req.params.symbolId);
      const data = await storage.getLatestMarketData(symbolId);
      
      if (!data) {
        return res.status(404).json({ error: 'No market data found' });
      }
      
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch market data' });
    }
  });

  // Real-time market data endpoint for charts
  app.get('/api/market-data/:symbol/historical', isAuthenticated, async (req, res) => {
    try {
      const { symbol } = req.params;
      const { from, to, resolution } = req.query;
      
      // Fetch authentic historical data from Yahoo Finance
      const yahooSymbol = `^NSEI`; // Map to appropriate index
      const response = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${yahooSymbol}?interval=${resolution}&period1=${from}&period2=${to}`);
      const data = await response.json();
      
      if (data.chart?.result?.[0]?.indicators?.quote?.[0]) {
        const quotes = data.chart.result[0].indicators.quote[0];
        const timestamps = data.chart.result[0].timestamp || [];
        
        const bars = timestamps.map((time: number, index: number) => ({
          time: time,
          open: quotes.open[index] || 0,
          high: quotes.high[index] || 0,  
          low: quotes.low[index] || 0,
          close: quotes.close[index] || 0,
          volume: quotes.volume[index] || 0
        })).filter((bar: any) => bar.open && bar.high && bar.low && bar.close);
        
        res.json(bars);
      } else {
        res.json([]);
      }
    } catch (error) {
      console.error('Error fetching historical data:', error);
      res.json([]);
    }
  });

  app.get('/api/marketdata/:symbolId/historical', async (req, res) => {
    try {
      const symbolId = parseInt(req.params.symbolId);
      const { from, to } = req.query;
      
      if (!from || !to) {
        return res.status(400).json({ error: 'from and to parameters required' });
      }
      
      const fromDate = new Date(from as string);
      const toDate = new Date(to as string);
      
      const data = await storage.getHistoricalData(symbolId, fromDate, toDate);
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch historical data' });
    }
  });

  // Watchlist (demo mode - will use authentication)
  app.get('/api/watchlist', async (req, res) => {
    try {
      const userId = "demo"; // Demo user ID for now
      const watchlist = await storage.getUserWatchlist(userId);
      res.json(watchlist);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch watchlist' });
    }
  });

  app.post('/api/watchlist', async (req, res) => {
    try {
      const userId = "demo"; // Demo user ID for now
      const data = insertWatchlistSchema.parse({ ...req.body, userId });
      const item = await storage.addToWatchlist(data);
      res.json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Invalid data', details: error.errors });
      }
      res.status(500).json({ error: 'Failed to add to watchlist' });
    }
  });

  app.delete('/api/watchlist/:symbolId', async (req, res) => {
    try {
      const userId = "demo"; // Demo user ID for now
      const symbolId = parseInt(req.params.symbolId);
      const success = await storage.removeFromWatchlist(userId, symbolId);
      
      if (!success) {
        return res.status(404).json({ error: 'Watchlist item not found' });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to remove from watchlist' });
    }
  });

  // Pine Scripts
  app.get('/api/pinescripts', async (req, res) => {
    try {
      const userId = "demo"; // Demo user ID for now
      const scripts = await storage.getUserPineScripts(userId);
      res.json(scripts);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch Pine Scripts' });
    }
  });

  app.post('/api/pinescripts', async (req, res) => {
    try {
      const userId = "demo"; // Use demo user for consistency
      const data = insertPineScriptSchema.parse({ ...req.body, userId });
      const script = await storage.createPineScript(data);
      res.json(script);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Invalid data', details: error.errors });
      }
      res.status(500).json({ error: 'Failed to create Pine Script' });
    }
  });

  app.put('/api/pinescripts/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const script = await storage.updatePineScript(id, updates);
      
      if (!script) {
        return res.status(404).json({ error: 'Pine Script not found' });
      }
      
      res.json(script);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update Pine Script' });
    }
  });

  app.post('/api/pinescripts/:id/execute', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const script = await storage.getPineScript(id);
      
      if (!script) {
        return res.status(404).json({ error: 'Pine Script not found' });
      }
      
      const { symbolId } = req.body;
      if (!symbolId) {
        return res.status(400).json({ error: 'Symbol ID required' });
      }
      
      const result = await pineScriptService.executeScript(script, symbolId);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Failed to execute Pine Script' });
    }
  });

  // Alerts
  app.get('/api/alerts', async (req, res) => {
    try {
      const userId = "demo"; // Demo user ID for now
      const alerts = await storage.getUserAlerts(userId);
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch alerts' });
    }
  });

  app.post('/api/alerts', async (req, res) => {
    try {
      const userId = 1; // In real app, get from session/auth
      const data = insertAlertSchema.parse({ ...req.body, userId });
      const alert = await storage.createAlert(data);
      res.json(alert);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Invalid data', details: error.errors });
      }
      res.status(500).json({ error: 'Failed to create alert' });
    }
  });

  return httpServer;
}
