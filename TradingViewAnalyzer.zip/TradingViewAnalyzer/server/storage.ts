import { users, symbols, marketData, watchlists, pineScripts, alerts, type User, type InsertUser, type UpsertUser, type Symbol, type InsertSymbol, type MarketData, type InsertMarketData, type Watchlist, type InsertWatchlist, type PineScript, type InsertPineScript, type Alert, type InsertAlert, type LiveMarketData, type OrderBook } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // User management (updated for authentication)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Symbol management
  getSymbol(id: number): Promise<Symbol | undefined>;
  getSymbolByName(symbol: string): Promise<Symbol | undefined>;
  getSymbols(): Promise<Symbol[]>;
  createSymbol(symbol: InsertSymbol): Promise<Symbol>;
  getActiveSymbols(): Promise<Symbol[]>;

  // Market data
  getLatestMarketData(symbolId: number): Promise<MarketData | undefined>;
  getHistoricalData(symbolId: number, from: Date, to: Date): Promise<MarketData[]>;
  createMarketData(data: InsertMarketData): Promise<MarketData>;
  
  // Watchlist
  getUserWatchlist(userId: string): Promise<(Watchlist & { symbol: Symbol })[]>;
  addToWatchlist(item: InsertWatchlist): Promise<Watchlist>;
  removeFromWatchlist(userId: string, symbolId: number): Promise<boolean>;

  // Pine Scripts
  getUserPineScripts(userId: string): Promise<PineScript[]>;
  getPineScript(id: number): Promise<PineScript | undefined>;
  createPineScript(script: InsertPineScript): Promise<PineScript>;
  updatePineScript(id: number, updates: Partial<PineScript>): Promise<PineScript | undefined>;
  deletePineScript(id: number): Promise<boolean>;

  // Alerts
  getUserAlerts(userId: string): Promise<(Alert & { symbol: Symbol })[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  updateAlert(id: number, updates: Partial<Alert>): Promise<Alert | undefined>;
  deleteAlert(id: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User operations for authentication
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Symbol management
  async getSymbol(id: number): Promise<Symbol | undefined> {
    const [symbol] = await db.select().from(symbols).where(eq(symbols.id, id));
    return symbol || undefined;
  }

  async getSymbolByName(symbol: string): Promise<Symbol | undefined> {
    const [symbolData] = await db.select().from(symbols).where(eq(symbols.symbol, symbol));
    return symbolData || undefined;
  }

  async getSymbols(): Promise<Symbol[]> {
    return await db.select().from(symbols);
  }

  async createSymbol(symbolData: InsertSymbol): Promise<Symbol> {
    const [symbol] = await db.insert(symbols).values(symbolData).returning();
    return symbol;
  }

  async getActiveSymbols(): Promise<Symbol[]> {
    return await db.select().from(symbols).where(eq(symbols.isActive, true));
  }

  // Market data operations
  async getLatestMarketData(symbolId: number): Promise<MarketData | undefined> {
    const [data] = await db.select().from(marketData)
      .where(eq(marketData.symbolId, symbolId))
      .orderBy(marketData.timestamp)
      .limit(1);
    return data || undefined;
  }

  async getHistoricalData(symbolId: number, from: Date, to: Date): Promise<MarketData[]> {
    // For now, return empty array - will implement with proper date filtering
    return [];
  }

  async createMarketData(data: InsertMarketData): Promise<MarketData> {
    const [marketDataEntry] = await db.insert(marketData).values(data).returning();
    return marketDataEntry;
  }

  // Watchlist operations
  async getUserWatchlist(userId: string): Promise<(Watchlist & { symbol: Symbol })[]> {
    const watchlistData = await db.select()
      .from(watchlists)
      .leftJoin(symbols, eq(watchlists.symbolId, symbols.id))
      .where(eq(watchlists.userId, userId));

    return watchlistData.map(item => ({
      ...item.watchlists,
      symbol: item.symbols!
    }));
  }

  async addToWatchlist(item: InsertWatchlist): Promise<Watchlist> {
    const [watchlistItem] = await db.insert(watchlists).values(item).returning();
    return watchlistItem;
  }

  async removeFromWatchlist(userId: string, symbolId: number): Promise<boolean> {
    const result = await db.delete(watchlists)
      .where(and(eq(watchlists.userId, userId), eq(watchlists.symbolId, symbolId)));
    return (result.rowCount ?? 0) > 0;
  }

  // Pine Script operations
  async getUserPineScripts(userId: string): Promise<PineScript[]> {
    return await db.select().from(pineScripts).where(eq(pineScripts.userId, userId));
  }

  async getPineScript(id: number): Promise<PineScript | undefined> {
    const [script] = await db.select().from(pineScripts).where(eq(pineScripts.id, id));
    return script || undefined;
  }

  async createPineScript(script: InsertPineScript): Promise<PineScript> {
    const [pineScript] = await db.insert(pineScripts).values(script).returning();
    return pineScript;
  }

  async updatePineScript(id: number, updates: Partial<PineScript>): Promise<PineScript | undefined> {
    const [updated] = await db.update(pineScripts)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(pineScripts.id, id))
      .returning();
    return updated || undefined;
  }

  async deletePineScript(id: number): Promise<boolean> {
    const result = await db.delete(pineScripts).where(eq(pineScripts.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Alert operations
  async getUserAlerts(userId: string): Promise<(Alert & { symbol: Symbol })[]> {
    const alertData = await db.select()
      .from(alerts)
      .leftJoin(symbols, eq(alerts.symbolId, symbols.id))
      .where(eq(alerts.userId, userId));

    return alertData.map(item => ({
      ...item.alerts,
      symbol: item.symbols!
    }));
  }

  async createAlert(alert: InsertAlert): Promise<Alert> {
    const [newAlert] = await db.insert(alerts).values(alert).returning();
    return newAlert;
  }

  async updateAlert(id: number, updates: Partial<Alert>): Promise<Alert | undefined> {
    const [updated] = await db.update(alerts)
      .set(updates)
      .where(eq(alerts.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteAlert(id: number): Promise<boolean> {
    const result = await db.delete(alerts).where(eq(alerts.id, id));
    return (result.rowCount ?? 0) > 0;
  }
}

export const storage = new DatabaseStorage();