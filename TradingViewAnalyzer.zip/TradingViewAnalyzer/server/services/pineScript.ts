import { type PineScript, type PineScriptSignal } from '@shared/schema';
import { storage } from '../storage';
import { marketDataService } from './marketData';

interface PineScriptResult {
  success: boolean;
  signals: PineScriptSignal[];
  indicators: Record<string, number>;
  error?: string;
  backtestResults?: {
    totalTrades: number;
    winRate: number;
    netPnL: number;
    maxDrawdown: number;
  };
}

class PineScriptService {
  private runningScripts: Map<number, boolean> = new Map();

  async executeScript(script: PineScript, symbolId: number): Promise<PineScriptResult> {
    try {
      // Get symbol and market data
      const symbol = await storage.getSymbol(symbolId);
      if (!symbol) {
        throw new Error('Symbol not found');
      }

      const currentData = marketDataService.getCurrentPrice(symbol.symbol);
      if (!currentData) {
        throw new Error('No market data available');
      }

      // Parse and execute Pine Script
      const result = this.parsePineScript(script.code, currentData);
      
      // Mark script as running
      this.runningScripts.set(script.id, true);

      return {
        success: true,
        signals: result.signals,
        indicators: result.indicators,
        backtestResults: result.backtestResults
      };
    } catch (error) {
      return {
        success: false,
        signals: [],
        indicators: {},
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  private parsePineScript(code: string, marketData: any): {
    signals: PineScriptSignal[];
    indicators: Record<string, number>;
    backtestResults: any;
  } {
    // Simplified Pine Script parser for demo purposes
    // In a real implementation, this would be a full Pine Script interpreter
    
    const indicators: Record<string, number> = {};
    const signals: PineScriptSignal[] = [];

    // Extract RSI calculation if present
    if (code.includes('ta.rsi')) {
      const rsiMatch = code.match(/ta\.rsi\([^,]+,\s*(\d+)\)/);
      const period = rsiMatch ? parseInt(rsiMatch[1]) : 14;
      indicators.rsi = this.calculateRSI(marketData.ltp, period);
    }

    // Extract Moving Average if present
    if (code.includes('ta.sma')) {
      const smaMatch = code.match(/ta\.sma\([^,]+,\s*(\d+)\)/);
      const period = smaMatch ? parseInt(smaMatch[1]) : 20;
      indicators.sma = this.calculateSMA(marketData.ltp, period);
    }

    // Extract Bollinger Bands if present
    if (code.includes('ta.bb')) {
      const bb = this.calculateBollingerBands(marketData.ltp, 20, 2);
      indicators.bb_upper = bb.upper;
      indicators.bb_middle = bb.middle;
      indicators.bb_lower = bb.lower;
    }

    // Generate signals based on conditions in the script
    if (code.includes('strategy.entry')) {
      // Simple RSI-based signals for demo
      if (indicators.rsi) {
        if (indicators.rsi < 30) {
          signals.push({
            symbol: marketData.symbol,
            action: 'BUY',
            price: marketData.ltp,
            quantity: 1,
            timestamp: Date.now(),
            strategy: 'RSI Oversold',
            confidence: 0.8
          });
        } else if (indicators.rsi > 70) {
          signals.push({
            symbol: marketData.symbol,
            action: 'SELL',
            price: marketData.ltp,
            quantity: 1,
            timestamp: Date.now(),
            strategy: 'RSI Overbought',
            confidence: 0.8
          });
        }
      }
    }

    // Generate mock backtest results
    const backtestResults = {
      totalTrades: Math.floor(Math.random() * 50) + 10,
      winRate: Math.round((Math.random() * 30 + 60) * 100) / 100, // 60-90%
      netPnL: Math.round((Math.random() * 20000 + 5000) * 100) / 100,
      maxDrawdown: Math.round((Math.random() * 5000 + 1000) * 100) / 100
    };

    return {
      signals,
      indicators,
      backtestResults
    };
  }

  private calculateRSI(currentPrice: number, period: number): number {
    // Simplified RSI calculation for demo
    // In real implementation, this would use historical data
    const random = Math.random();
    if (random < 0.2) return Math.random() * 30; // Oversold
    if (random > 0.8) return 70 + Math.random() * 30; // Overbought
    return 30 + Math.random() * 40; // Normal range
  }

  private calculateSMA(currentPrice: number, period: number): number {
    // Simplified SMA calculation
    return currentPrice * (0.95 + Math.random() * 0.1);
  }

  private calculateBollingerBands(currentPrice: number, period: number, stdDev: number) {
    const sma = this.calculateSMA(currentPrice, period);
    const deviation = currentPrice * 0.02; // 2% deviation
    
    return {
      upper: sma + (deviation * stdDev),
      middle: sma,
      lower: sma - (deviation * stdDev)
    };
  }

  isScriptRunning(scriptId: number): boolean {
    return this.runningScripts.get(scriptId) || false;
  }

  stopScript(scriptId: number): void {
    this.runningScripts.set(scriptId, false);
  }

  getDefaultPineScriptTemplate(): string {
    return `// @version=6
strategy("F&O Trading Strategy", overlay=true, default_qty_type=strategy.percent_of_equity, default_qty_value=10)

// Input parameters
length = input.int(14, "RSI Length", minval=1)
rsi_overbought = input.int(70, "RSI Overbought")
rsi_oversold = input.int(30, "RSI Oversold")

// Calculate RSI
rsi_value = ta.rsi(close, length)

// Strategy conditions
long_condition = rsi_value < rsi_oversold
short_condition = rsi_value > rsi_overbought

// Execute trades
if (long_condition)
    strategy.entry("Long", strategy.long)

if (short_condition)
    strategy.entry("Short", strategy.short)

// Plot RSI
plot(rsi_value, "RSI", color=color.purple)
hline(70, "Overbought", color=color.red)
hline(30, "Oversold", color=color.green)
hline(50, "Midline", color=color.gray)`;
  }
}

export const pineScriptService = new PineScriptService();
