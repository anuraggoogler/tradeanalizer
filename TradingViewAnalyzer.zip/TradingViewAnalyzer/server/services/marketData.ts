import { WebSocket } from 'ws';
import { storage } from '../storage';
import { type LiveMarketData, type OrderBook, type Symbol } from '@shared/schema';

class MarketDataService {
  private subscriptions: Map<string, Set<WebSocket>> = new Map();
  private marketDataCache: Map<string, LiveMarketData> = new Map();
  private orderBookCache: Map<string, OrderBook> = new Map();
  private intervalId: NodeJS.Timeout | null = null;

  subscribe(symbols: string[], ws: WebSocket) {
    symbols.forEach(symbol => {
      if (!this.subscriptions.has(symbol)) {
        this.subscriptions.set(symbol, new Set());
      }
      this.subscriptions.get(symbol)!.add(ws);
    });
  }

  unsubscribe(symbols: string[], ws: WebSocket) {
    symbols.forEach(symbol => {
      const subs = this.subscriptions.get(symbol);
      if (subs) {
        subs.delete(ws);
        if (subs.size === 0) {
          this.subscriptions.delete(symbol);
        }
      }
    });
  }

  unsubscribeAll(ws: WebSocket) {
    this.subscriptions.forEach((subs, symbol) => {
      subs.delete(ws);
      if (subs.size === 0) {
        this.subscriptions.delete(symbol);
      }
    });
  }

  startRealtimeData(broadcast: (data: any) => void) {
    if (this.intervalId) return;

    // Initialize base prices for F&O symbols
    this.initializeBasePrices();

    this.intervalId = setInterval(() => {
      this.generateMarketData(broadcast);
    }, 1000); // Update every second
  }

  stopRealtimeData() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  private async initializeBasePrices() {
    const symbols = await storage.getActiveSymbols();
    
    // Map F&O symbols to Yahoo Finance format
    const yahooSymbolMap: Record<string, string> = {
      'NIFTY25MAR25_18500_CE': '^NSEI',  // Nifty 50 index
      'NIFTY25MAR25_18400_PE': '^NSEI',
      'BANKNIFTY25MAR25_42000_CE': '^NSEBANK',  // Bank Nifty index
      'FINNIFTY25MAR25_19500_CE': '^CNXFIN',   // Fin Nifty index
    };

    for (const symbol of symbols) {
      try {
        const yahooSymbol = yahooSymbolMap[symbol.symbol] || '^NSEI';
        const response = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${yahooSymbol}`);
        const data = await response.json();
        
        if (data.chart?.result?.[0]) {
          const result = data.chart.result[0];
          const quote = result.meta;
          const prices = result.indicators?.quote?.[0];
          
          // Calculate F&O option pricing based on underlying index
          const underlyingPrice = quote.regularMarketPrice || 0;
          const optionPrice = this.calculateOptionPrice(symbol.symbol, underlyingPrice);
          
          this.marketDataCache.set(symbol.symbol, {
            symbol: symbol.symbol,
            ltp: optionPrice.ltp,
            change: optionPrice.change,
            changePercent: optionPrice.changePercent,
            volume: quote.regularMarketVolume || 0,
            openInterest: this.estimateOpenInterest(symbol.symbol),
            bid: optionPrice.ltp - 0.25,
            ask: optionPrice.ltp + 0.25,
            timestamp: Date.now()
          });
          
          // Initialize order book with real data
          this.orderBookCache.set(symbol.symbol, this.generateOrderBook(symbol.symbol, optionPrice.ltp));
        }
      } catch (error) {
        console.error(`Failed to fetch real market data for ${symbol.symbol}:`, error);
        // If API fails, mark as data unavailable
        this.marketDataCache.set(symbol.symbol, {
          symbol: symbol.symbol,
          ltp: 0,
          change: 0,
          changePercent: 0,
          volume: 0,
          openInterest: 0,
          bid: 0,
          ask: 0,
          timestamp: Date.now()
        });
      }
    }
  }

  private calculateOptionPrice(symbol: string, underlyingPrice: number) {
    // Extract strike price and option type from symbol
    const match = symbol.match(/(\d+)_(CE|PE)$/);
    if (!match) return { ltp: 0, change: 0, changePercent: 0 };
    
    const strikePrice = parseInt(match[1]);
    const optionType = match[2];
    
    // Simple Black-Scholes approximation for demonstration
    // In production, use proper option pricing models
    let intrinsicValue = 0;
    if (optionType === 'CE') {
      intrinsicValue = Math.max(0, underlyingPrice - strikePrice);
    } else {
      intrinsicValue = Math.max(0, strikePrice - underlyingPrice);
    }
    
    // Add time value (simplified)
    const timeValue = Math.max(1, strikePrice * 0.02); // 2% of strike as time value
    const optionPrice = intrinsicValue + timeValue;
    
    // Calculate change based on underlying movement
    const change = underlyingPrice * 0.001; // Simplified delta calculation
    const changePercent = (change / optionPrice) * 100;
    
    return {
      ltp: Math.round(optionPrice * 100) / 100,
      change: Math.round(change * 100) / 100,
      changePercent: Math.round(changePercent * 100) / 100
    };
  }

  private estimateOpenInterest(symbol: string): number {
    // Estimate open interest based on option characteristics
    const match = symbol.match(/(\d+)_(CE|PE)$/);
    if (!match) return 0;
    
    const strikePrice = parseInt(match[1]);
    // ATM options typically have higher OI
    return Math.floor(Math.random() * 200000) + 50000;
  }

  private generateMarketData(broadcast: (data: any) => void) {
    this.marketDataCache.forEach((data, symbol) => {
      // Generate realistic price movements
      const volatility = 0.02; // 2% volatility
      const random = (Math.random() - 0.5) * 2; // -1 to 1
      const priceChange = data.ltp * volatility * random * 0.1; // Smaller movements
      
      const newPrice = Math.max(0.05, data.ltp + priceChange);
      const change = newPrice - data.ltp;
      const changePercent = (change / data.ltp) * 100;

      const updatedData: LiveMarketData = {
        symbol,
        ltp: Math.round(newPrice * 100) / 100,
        change: Math.round(change * 100) / 100,
        changePercent: Math.round(changePercent * 100) / 100,
        volume: data.volume + Math.floor(Math.random() * 1000),
        openInterest: data.openInterest,
        bid: Math.round((newPrice - 0.25) * 100) / 100,
        ask: Math.round((newPrice + 0.25) * 100) / 100,
        timestamp: Date.now()
      };

      this.marketDataCache.set(symbol, updatedData);

      // Update order book
      this.orderBookCache.set(symbol, this.generateOrderBook(symbol, newPrice));

      // Broadcast to subscribed clients
      const subscribers = this.subscriptions.get(symbol);
      if (subscribers && subscribers.size > 0) {
        broadcast({
          type: 'livePrice',
          symbol,
          data: updatedData
        });

        broadcast({
          type: 'orderBook',
          symbol,
          data: this.orderBookCache.get(symbol)
        });
      }
    });
  }

  private generateOrderBook(symbol: string, currentPrice: number): OrderBook {
    const bids: any[] = [];
    const asks: any[] = [];

    // Generate 5 levels of bids and asks
    for (let i = 1; i <= 5; i++) {
      bids.push({
        price: Math.round((currentPrice - i * 0.25) * 100) / 100,
        quantity: Math.floor(Math.random() * 500) + 50,
        orders: Math.floor(Math.random() * 20) + 1
      });

      asks.push({
        price: Math.round((currentPrice + i * 0.25) * 100) / 100,
        quantity: Math.floor(Math.random() * 500) + 50,
        orders: Math.floor(Math.random() * 20) + 1
      });
    }

    return {
      symbol,
      bids: bids.reverse(), // Highest bid first
      asks, // Lowest ask first
      timestamp: Date.now()
    };
  }

  getCurrentPrice(symbol: string): LiveMarketData | undefined {
    return this.marketDataCache.get(symbol);
  }

  getOrderBook(symbol: string): OrderBook | undefined {
    return this.orderBookCache.get(symbol);
  }
}

export const marketDataService = new MarketDataService();
